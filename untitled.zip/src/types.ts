export type UserRole = "Admin" | "Manager" | "Executive";

export type LeadStatus =
  | "New"
  | "Connected"
  | "Follow-up"
  | "Negotiation"
  | "Site Visit Scheduled"
  | "Site Visit Completed"
  | "Booked"
  | "Lost";

export type AutomationStatus = "On Track" | "Follow-up Due" | "CRITICAL OVERDUE" | "Escalated";

export interface Tenant {
  tenantId: string;
  companyName: string;
  ownerEmail: string;
  subscriptionPlan: "Standard" | "Enterprise" | "White-Label";
  whatsappConfig: {
    apiKey: string;
    phoneId: string;
  };
  webhookUrl: string;
  routingRules: { city: string; executiveId: string }[];
}

export interface User {
  userId: string;
  tenantId: string;
  name: string;
  email: string;
  role: UserRole;
  kpiTarget?: number;
}

export interface Lead {
  id: string;
  tenantId: string;
  leadDate: string;
  customerName: string;
  mobileNumber: string;
  city: string;
  budget: number;
  project: string;
  unitType: string;
  leadSource: "Facebook" | "Website" | "Walk-in" | "99acres";
  assignedExecutiveId: string;
  leadStatus: LeadStatus;
  nextFollowUpDate: string;
  automationStatus: AutomationStatus;
  notes?: string;
}

export interface Booking {
  bookingId: string;
  tenantId: string;
  leadId: string;
  propertyName: string;
  unitNumber: string;
  dealValue: number;
  amountReceived: number;
  balanceDue: number;
  paymentStatus: "Fully Paid" | "Partially Paid" | "Balance Overdue";
  nextDueDate: string;
  createdAt: string;
}

export interface Payment {
  paymentId: string;
  tenantId: string;
  bookingId: string;
  amount: number;
  paymentDate: string;
  paymentMethod: string;
  status: "Cleared" | "Pending" | "Failed";
}

export interface AutomationLog {
  logId: string;
  tenantId: string;
  leadId: string;
  eventType: "Lead Ingested" | "AI Routing" | "Welcome Text Dispatched" | "SLA Escalation" | "Followup Updated" | "Routing Exception";
  executionTimestamp: string;
  status: "Success" | "Failure";
  details: string;
}
