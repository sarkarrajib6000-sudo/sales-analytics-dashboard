import React, { useState, useEffect } from "react";
import { AppProvider, useApp } from "./context/AppContext";
import SettingsPanel from "./components/SettingsPanel";
import WebhookTester from "./components/WebhookTester";
import LeadWorkflow from "./components/LeadWorkflow";
import TeamScorecard from "./components/TeamScorecard";
import CashFlowMonitor from "./components/CashFlowMonitor";
import KpiDashboard from "./components/KpiDashboard";
import {
  Webhook,
  Network,
  Users,
  Trophy,
  Landmark,
  Settings,
  History,
  CheckCircle,
  Clock,
  Zap,
  ChevronRight,
  ShieldCheck,
  PieChart,
  Building2,
  UserCheck,
  RefreshCw,
  Sun,
  Moon,
  Menu,
  X,
  Activity,
  User as UserIcon,
  ChevronDown,
  Sparkles,
  Layers,
  Database
} from "lucide-react";

function DashboardContent() {
  const {
    logs,
    activeTenantId,
    setActiveTenantId,
    activeTenant,
    simulatedUsers,
    currentUserId,
    setCurrentUserId,
    currentUser,
    triggerResetDb,
    loading
  } = useApp();

  const [activeTab, setActiveTab] = useState<"pipeline" | "webhook" | "scorecard" | "cashflow" | "settings" | "kpi">("pipeline");
  const [theme, setTheme] = useState<'light' | 'dark'>(() => (localStorage.getItem('theme') as 'light' | 'dark') || 'light');
  
  // Mobile states
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isTenantDropdownOpen, setIsTenantDropdownOpen] = useState(false);
  const [isPersonaDropdownOpen, setIsPersonaDropdownOpen] = useState(false);
  
  // Collapsible Logs Panel
  const [showLogsPanel, setShowLogsPanel] = useState(true);

  useEffect(() => {
    localStorage.setItem('theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  // Navigation menu items
  const menuItems = [
    {
      id: "pipeline",
      label: "Lead SLA Pipeline",
      desc: "SLA tracking & priority actions",
      icon: Network,
      color: "text-indigo-500 dark:text-indigo-400",
      shortcut: "⌥1"
    },
    {
      id: "webhook",
      label: "Inbound API Ingress",
      desc: "Webhook payload simulation gateway",
      icon: Webhook,
      color: "text-emerald-500 dark:text-emerald-400",
      shortcut: "⌥2"
    },
    {
      id: "scorecard",
      label: "Team Scorecard",
      desc: "Live performance leaderboard",
      icon: Trophy,
      color: "text-amber-500 dark:text-amber-400",
      shortcut: "⌥3"
    },
    {
      id: "kpi",
      label: "KPI Performance",
      desc: "Real-time health dashboards",
      icon: PieChart,
      color: "text-purple-500 dark:text-purple-400",
      shortcut: "⌥4"
    },
    {
      id: "cashflow",
      label: "Billing Ledger",
      desc: "Accounts receivable & installment ledger",
      icon: Landmark,
      color: "text-rose-500 dark:text-rose-400",
      shortcut: "⌥5"
    },
    {
      id: "settings",
      label: "White-Label Setup",
      desc: "API credentials & team routing",
      icon: Settings,
      color: "text-slate-400 dark:text-slate-350",
      shortcut: "⌥6"
    }
  ];

  // Shortcut key listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && !isNaN(Number(e.key))) {
        const index = Number(e.key) - 1;
        if (index >= 0 && index < menuItems.length) {
          setActiveTab(menuItems[index].id as any);
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50/80 text-slate-900'} flex font-sans transition-colors duration-300`} id="propflow-master-container">
      
      {/* ========================================================= */}
      {/* LEFT NAVIGATION SIDEBAR (Enterprise Control Panel) */}
      {/* ========================================================= */}
      
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-72 bg-slate-900 dark:bg-slate-950 text-slate-200 border-r border-slate-800 dark:border-slate-900 shrink-0 h-screen sticky top-0 overflow-y-auto z-40">
        
        {/* Brand Header */}
        <div className="p-6 border-b border-slate-800/80 dark:border-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-tr from-indigo-600 to-violet-500 rounded-xl text-white font-extrabold text-sm tracking-wide flex items-center justify-center shadow-lg shadow-indigo-500/20">
              PF
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-white font-display flex items-center gap-1.5">
                PropFlow <span className="text-[9px] bg-slate-800 dark:bg-slate-900 text-indigo-400 font-semibold px-2 py-0.5 rounded-full border border-slate-700/60 dark:border-slate-800">v1.2</span>
              </h1>
              <p className="text-[10px] text-slate-400 font-mono tracking-wide">Enterprise CRM Hub</p>
            </div>
          </div>
        </div>

        {/* Workspace Selector (Tenant Dropdown) */}
        <div className="px-4 py-4 border-b border-slate-800/80 dark:border-slate-900 relative">
          <label className="block text-[9px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-2 px-2">
            Active Workspace
          </label>
          <button
            onClick={() => setIsTenantDropdownOpen(!isTenantDropdownOpen)}
            className="w-full flex items-center justify-between gap-3 bg-slate-800/40 dark:bg-slate-900/40 hover:bg-slate-800/80 dark:hover:bg-slate-900/80 text-left px-3.5 py-2.5 rounded-xl border border-slate-700/50 dark:border-slate-800/80 text-xs font-semibold text-white transition-all duration-200 shadow-inner group"
          >
            <div className="flex items-center gap-2.5 truncate">
              <Building2 className="w-4 h-4 text-indigo-400 shrink-0 group-hover:scale-115 transition-transform" />
              <span className="truncate text-[13px]">
                {activeTenantId === "skyline-realty" ? "Skyline Realty" : "Vanguard Developers"}
              </span>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-400 shrink-0 group-hover:text-slate-200 transition-colors" />
          </button>

          {isTenantDropdownOpen && (
            <div className="absolute left-4 right-4 mt-2 bg-slate-800 dark:bg-slate-900 border border-slate-700 dark:border-slate-850 rounded-xl shadow-xl z-30 overflow-hidden text-xs py-1.5 animate-in fade-in slide-in-from-top-1.5 duration-150">
              <button
                onClick={() => {
                  setActiveTenantId("skyline-realty");
                  setIsTenantDropdownOpen(false);
                }}
                className={`w-full px-4 py-3 text-left hover:bg-slate-700/60 dark:hover:bg-slate-800/60 transition-colors flex items-center justify-between ${activeTenantId === "skyline-realty" ? "text-indigo-400 font-bold bg-slate-700/35" : "text-slate-300"}`}
              >
                <span>Skyline Realty (Mumbai)</span>
                {activeTenantId === "skyline-realty" && <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />}
              </button>
              <button
                onClick={() => {
                  setActiveTenantId("vanguard-devs");
                  setIsTenantDropdownOpen(false);
                }}
                className={`w-full px-4 py-3 text-left hover:bg-slate-700/60 dark:hover:bg-slate-800/60 transition-colors flex items-center justify-between ${activeTenantId === "vanguard-devs" ? "text-indigo-400 font-bold bg-slate-700/35" : "text-slate-300"}`}
              >
                <span>Vanguard Developers (Pune)</span>
                {activeTenantId === "vanguard-devs" && <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />}
              </button>
            </div>
          )}
        </div>

        {/* Main CRM Modules Navigation */}
        <div className="flex-1 px-4 py-4 space-y-1.5 overflow-y-auto">
          <span className="block text-[9px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-3 px-2">
            Core Modules
          </span>
          <nav className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`w-full px-3 py-3 rounded-xl text-left flex items-center justify-between group transition-all duration-150 ${
                    isActive
                      ? "bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-md shadow-indigo-600/20 border-l-4 border-white"
                      : "hover:bg-slate-800/45 dark:hover:bg-slate-900/40 text-slate-300 hover:text-white"
                  }`}
                  id={`nav-tab-${item.id}`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 duration-200 ${isActive ? "text-white" : item.color}`} />
                    <div className="min-w-0">
                      <div className="text-xs font-semibold">{item.label}</div>
                      <div className={`text-[10px] font-normal leading-tight mt-0.5 truncate ${isActive ? "text-indigo-200" : "text-slate-400 group-hover:text-slate-300"}`}>
                        {item.desc}
                      </div>
                    </div>
                  </div>
                  <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${
                    isActive 
                      ? "bg-indigo-700 border-indigo-500 text-indigo-200" 
                      : "bg-slate-800 border-slate-700 text-slate-500 group-hover:text-slate-400 group-hover:border-slate-650"
                  }`}>
                    {item.shortcut}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Subscription Tier Details & Simulated Info */}
        {activeTenant && (
          <div className="px-5 py-4 mx-4 mb-4 bg-slate-800/30 dark:bg-slate-900/30 border border-slate-800/60 dark:border-slate-850 rounded-xl text-xs space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Tenant Tier</span>
              <span className="bg-gradient-to-r from-indigo-950 to-violet-950 text-indigo-300 border border-indigo-800/50 px-2 py-0.5 rounded-full text-[9px] font-bold">
                {activeTenant.subscriptionPlan}
              </span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400">Router Status:</span>
              <span className="text-emerald-400 font-medium flex items-center gap-1 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Auto-Active
              </span>
            </div>
            <div className="w-full bg-slate-800 dark:bg-slate-900 h-1 rounded-full overflow-hidden">
              <div className="bg-indigo-500 h-full w-4/5" />
            </div>
          </div>
        )}

        {/* Bottom Utility Actions: Theme & Database Reload */}
        <div className="p-4 border-t border-slate-800/80 dark:border-slate-900 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={toggleTheme}
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Corporate Dark'}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700/80 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition-all duration-150 flex items-center justify-center gap-1.5 border border-slate-700/30 shadow-xs"
            >
              {theme === 'dark' ? <Sun className="w-3.5 h-3.5 text-amber-400 animate-spin-slow" /> : <Moon className="w-3.5 h-3.5 text-indigo-400" />}
              <span>{theme === 'dark' ? 'Light' : 'Dark'}</span>
            </button>

            <button
              onClick={() => {
                if (confirm("Reset the Firestore database to default records?")) {
                  triggerResetDb();
                }
              }}
              title="Reload starting entries into Database"
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700/80 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition-all duration-150 flex items-center justify-center gap-1.5 border border-slate-700/30 shadow-xs"
            >
              <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
              <span>Reset DB</span>
            </button>
          </div>
        </div>

        {/* Identity Profile Widget (Persona Switcher) */}
        {currentUser && (
          <div className="p-4 border-t border-slate-800/80 dark:border-slate-900 bg-slate-950/20 relative">
            <button
              onClick={() => setIsPersonaDropdownOpen(!isPersonaDropdownOpen)}
              className="w-full flex items-center gap-3 hover:bg-slate-800/40 p-2 rounded-xl transition-all duration-150 text-left border border-transparent hover:border-slate-800/80 group"
            >
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-indigo-900 to-indigo-700 border border-indigo-500/30 flex items-center justify-center text-indigo-100 font-black text-sm shrink-0 uppercase shadow-inner">
                {currentUser.name.charAt(0)}
              </div>
              <div className="min-w-0 flex-1 leading-tight">
                <div className="text-xs font-bold text-white truncate group-hover:text-indigo-300 transition-colors">{currentUser.name}</div>
                <div className="text-[10px] text-indigo-400 mt-0.5 truncate flex items-center gap-1 font-mono">
                  <UserCheck className="w-3 h-3 shrink-0" />
                  <span>{currentUser.role} ID</span>
                </div>
              </div>
              <ChevronDown className="w-4 h-4 text-slate-500 shrink-0 group-hover:text-slate-300 transition-colors" />
            </button>

            {isPersonaDropdownOpen && (
              <div className="absolute bottom-18 left-4 right-4 bg-slate-850 dark:bg-slate-900 border border-slate-750 dark:border-slate-800 rounded-xl shadow-2xl z-30 overflow-hidden py-1.5 max-h-56 overflow-y-auto animate-in fade-in slide-in-from-bottom-2 duration-150">
                <div className="px-3.5 py-2 border-b border-slate-750 dark:border-slate-800 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                  Simulate Live User ID:
                </div>
                {simulatedUsers.map((user) => (
                  <button
                    key={user.userId}
                    onClick={() => {
                      setCurrentUserId(user.userId);
                      setIsPersonaDropdownOpen(false);
                    }}
                    className={`w-full px-3.5 py-2.5 text-left hover:bg-slate-750/70 dark:hover:bg-slate-800/70 transition-colors text-xs flex items-center justify-between ${user.userId === currentUserId ? "text-indigo-400 font-bold bg-slate-750/30 dark:bg-slate-800/30" : "text-slate-300"}`}
                  >
                    <div className="truncate">
                      <div className="font-semibold">{user.name}</div>
                      <div className="text-[9px] text-slate-500 font-mono">{user.email}</div>
                    </div>
                    <span className={`text-[8px] font-bold px-2 py-0.5 rounded-full uppercase ${
                      user.role === 'Admin' ? 'bg-rose-950/60 text-rose-300 border border-rose-900/40' : user.role === 'Manager' ? 'bg-amber-950/60 text-amber-300 border border-amber-900/40' : 'bg-emerald-950/60 text-emerald-300 border border-emerald-900/40'
                    }`}>
                      {user.role}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

      </aside>

      {/* ========================================================= */}
      {/* MOBILE HEADER & SIDEBAR TRAIL */}
      {/* ========================================================= */}
      <div className="lg:hidden flex flex-col w-full flex-1">
        <header className="h-16 bg-slate-900 text-slate-100 border-b border-slate-800 px-4 flex items-center justify-between shrink-0 sticky top-0 z-40">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMobileSidebarOpen(true)}
              className="p-1.5 hover:bg-slate-800 rounded-md text-slate-300 transition-colors"
            >
              <Menu className="w-6 h-6" />
            </button>
            <span className="font-display font-bold text-md text-white">PropFlow</span>
            <span className="text-[8px] bg-slate-800 text-indigo-400 font-bold px-1.5 py-0.2 rounded">v1.2</span>
          </div>
          <div className="flex items-center gap-2">
            {currentUser && (
              <span className={`text-[9px] px-2.5 py-0.5 rounded-full font-bold uppercase ${
                currentUser.role === 'Admin' ? 'bg-red-900/30 text-red-300 border border-red-800/20' : 'bg-emerald-900/30 text-emerald-300 border border-emerald-800/20'
              }`}>
                {currentUser.role}
              </span>
            )}
          </div>
        </header>

        {/* Mobile Sidebar Modal Overlay */}
        {isMobileSidebarOpen && (
          <div className="fixed inset-0 z-50 flex lg:hidden">
            <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs" onClick={() => setIsMobileSidebarOpen(false)} />
            
            <div className="relative flex flex-col w-72 max-w-sm bg-slate-900 text-slate-100 h-full p-4 overflow-y-auto space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="font-display font-bold text-base text-white">PropFlow SaaS</span>
                <button onClick={() => setIsMobileSidebarOpen(false)} className="p-1.5 hover:bg-slate-800 rounded-md text-slate-400">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Workspace Selector */}
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Active Workspace</label>
                <select
                  value={activeTenantId}
                  onChange={(e) => setActiveTenantId(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg text-xs font-semibold px-2 py-2 text-white"
                >
                  <option value="skyline-realty">Skyline Realty (Mumbai & Delhi)</option>
                  <option value="vanguard-devs">Vanguard Developers (Pune & Bangalore)</option>
                </select>
              </div>

              {/* Identity Select */}
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Simulate Persona</label>
                <select
                  value={currentUserId}
                  onChange={(e) => setCurrentUserId(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg text-xs font-semibold px-2 py-2 text-white"
                >
                  {simulatedUsers.map((user) => (
                    <option key={user.userId} value={user.userId}>
                      {user.name} ({user.role})
                    </option>
                  ))}
                </select>
              </div>

              {/* CRM modules list */}
              <div className="space-y-1">
                <span className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">CRM Modules</span>
                {menuItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id as any);
                        setIsMobileSidebarOpen(false);
                      }}
                      className={`w-full px-3 py-2 rounded-lg text-left flex items-center gap-3 ${
                        isActive ? "bg-indigo-600 text-white" : "hover:bg-slate-800 text-slate-300"
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <div>
                        <div className="text-xs font-semibold">{item.label}</div>
                        <div className={`text-[10px] ${isActive ? "text-indigo-200" : "text-slate-400"}`}>{item.desc}</div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Utility actions */}
              <div className="pt-4 border-t border-slate-800 space-y-2 text-xs">
                <button
                  onClick={() => {
                    toggleTheme();
                    setIsMobileSidebarOpen(false);
                  }}
                  className="w-full px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-center font-bold text-slate-200"
                >
                  {theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Corporate Dark'}
                </button>
                <button
                  onClick={() => {
                    if (confirm("Reset the database?")) {
                      triggerResetDb();
                      setIsMobileSidebarOpen(false);
                    }
                  }}
                  className="w-full px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-center font-bold text-slate-200"
                >
                  Reset Mock Database
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic content rendering with modern header */}
        <div className="flex-1 flex flex-col min-w-0">
          
          {/* Main workspace breadcrumb header */}
          <header className="h-16 bg-white dark:bg-slate-950 border-b border-slate-250 dark:border-slate-850 px-6 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-mono hidden sm:inline">Workspace</span>
              <ChevronRight className="w-3.5 h-3.5 text-slate-300 hidden sm:inline" />
              <span className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold uppercase font-mono tracking-wider">
                {activeTenantId === "skyline-realty" ? "Skyline Realty" : "Vanguard Devs"}
              </span>
              <ChevronRight className="w-3.5 h-3.5 text-slate-300" />
              <span className="text-xs font-bold text-slate-800 dark:text-slate-100 uppercase tracking-wide">
                {menuItems.find(m => m.id === activeTab)?.label}
              </span>
            </div>

            <div className="flex items-center gap-3 text-xs">
              {/* Database sync pulse */}
              <div className="flex items-center gap-1.5 text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold font-mono hidden md:flex">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                </span>
                <span>Firestore Active</span>
              </div>

              {/* Logs Drawer Toggle button */}
              <button
                onClick={() => setShowLogsPanel(!showLogsPanel)}
                className={`px-3 py-1.5 rounded-lg border font-bold text-xs flex items-center gap-2 transition-all duration-150 shadow-xs ${
                  showLogsPanel 
                    ? "bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-950/40 dark:border-indigo-900 dark:text-indigo-400" 
                    : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300"
                }`}
              >
                <Activity className="w-3.5 h-3.5 text-indigo-500" />
                <span>Logs Audit ({logs.length})</span>
              </button>
            </div>
          </header>

          {/* Main workspace frame containing content and audit logs pane side-by-side */}
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden min-h-[calc(100vh-8rem)]">
            
            {/* Left Content Area */}
            <main className="flex-1 p-6 overflow-y-auto space-y-6">
              {loading ? (
                <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md border border-slate-200 dark:border-slate-800 p-12 text-center h-[500px] flex flex-col items-center justify-center">
                  <div className="w-10 h-10 border-4 border-slate-200 border-t-indigo-600 rounded-full animate-spin mb-4" />
                  <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">Connecting to PropFlow Workspace...</p>
                  <p className="text-xs text-slate-400 mt-1">Downloading tenant-isolated database shards.</p>
                </div>
              ) : (
                <>
                  {activeTab === "pipeline" && <LeadWorkflow />}
                  {activeTab === "webhook" && <WebhookTester />}
                  {activeTab === "scorecard" && <TeamScorecard />}
                  {activeTab === "kpi" && <KpiDashboard />}
                  {activeTab === "cashflow" && <CashFlowMonitor />}
                  {activeTab === "settings" && <SettingsPanel />}
                </>
              )}
            </main>

            {/* Right Collapsible Audit Trail Shelf */}
            {showLogsPanel && (
              <aside className="w-full md:w-80 lg:w-96 border-t md:border-t-0 md:border-l border-slate-200 dark:border-slate-850 bg-white dark:bg-slate-950 p-4 flex flex-col shrink-0 h-96 md:h-auto overflow-hidden">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-850 pb-3 mb-3 shrink-0">
                  <div className="flex items-center gap-1.5 text-slate-800 dark:text-white font-bold text-xs uppercase tracking-wider font-display">
                    <History className="w-4 h-4 text-indigo-500 animate-pulse" />
                    Real-Time Logs Audit
                  </div>
                  <span className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold font-mono text-[9px] px-2 py-0.5 rounded-full border border-slate-200/55 dark:border-slate-700">
                    Cloud Firestore
                  </span>
                </div>

                {/* Real-Time Stream */}
                <div className="flex-1 overflow-y-auto space-y-2 pr-1 text-[11px]">
                  {logs.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 italic">
                      No system events logged. Trigger an inbound webhook or post a follow-up.
                    </div>
                  ) : (
                    logs.slice(0, 20).map((log, idx) => {
                      const time = new Date(log.executionTimestamp).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                        second: "2-digit"
                      });

                      return (
                        <div
                          key={log.logId || idx}
                          className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-850 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors space-y-1 bg-slate-50/50 dark:bg-slate-900/30"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-800 dark:text-slate-200 text-[9px] tracking-wide uppercase flex items-center gap-1">
                              <Zap className="w-3 h-3 text-indigo-500 shrink-0" />
                              {log.eventType}
                            </span>
                            <span className="text-[9px] text-slate-400 font-mono">{time}</span>
                          </div>
                          <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed font-sans">{log.details}</p>
                          <div className="flex justify-between items-center text-[9px] pt-1 text-slate-400 border-t border-dashed border-slate-100 dark:border-slate-850/60 mt-1.5">
                            <span className="font-mono">Ref ID: {log.leadId}</span>
                            <span className={`font-semibold uppercase text-[8px] ${log.status === "Success" ? "text-emerald-600" : "text-rose-600"}`}>
                              ● {log.status}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </aside>
            )}

          </div>
        </div>
      </div>

    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <DashboardContent />
    </AppProvider>
  );
}
