import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { DollarSign, Landmark, Plus, RefreshCw, AlertCircle, CheckCircle, Scale, ShieldAlert, Sparkles, X, CreditCard } from "lucide-react";

export default function CashFlowMonitor() {
  const {
    bookings,
    payments,
    leads,
    currentUser,
    addPayment,
    addBooking
  } = useApp();

  const [showPayModal, setShowPayModal] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);

  // Installment States
  const [selectedBookingId, setSelectedBookingId] = useState("");
  const [payAmount, setPayAmount] = useState("");
  const [payMethod, setPayMethod] = useState("Wire Transfer");

  // New Booking States (To test deal creations)
  const [bookingLeadId, setBookingLeadId] = useState("");
  const [bookingProject, setBookingProject] = useState("");
  const [bookingUnit, setBookingUnit] = useState("");
  const [bookingValue, setBookingValue] = useState("");
  const [bookingPaid, setBookingPaid] = useState("");

  const isAdmin = currentUser?.role === "Admin";

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      alert("Role Permission Lock: Only Tenant Administrators are permitted to log payments.");
      return;
    }
    if (!selectedBookingId || !payAmount) return;

    try {
      await addPayment({
        bookingId: selectedBookingId,
        amount: Number(payAmount),
        paymentDate: new Date().toISOString(),
        paymentMethod: payMethod,
        status: "Cleared"
      });
      setPayAmount("");
      setSelectedBookingId("");
      setShowPayModal(false);
    } catch (err) {
      alert("Error adding payment: " + err);
    }
  };

  const handleCreateBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      alert("Role Permission Lock: Only Tenant Administrators can confirm bookings.");
      return;
    }
    if (!bookingLeadId || !bookingValue) return;

    try {
      const val = Number(bookingValue);
      const paid = Number(bookingPaid) || 0;
      const bal = val - paid;

      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 30);

      await addBooking({
        leadId: bookingLeadId,
        propertyName: bookingProject || "PropFlow Regency",
        unitNumber: bookingUnit || "G-101",
        dealValue: val,
        amountReceived: paid,
        balanceDue: bal,
        paymentStatus: paid >= val ? "Fully Paid" : "Partially Paid",
        nextDueDate: tomorrow.toISOString()
      });

      setBookingLeadId("");
      setBookingProject("");
      setBookingUnit("");
      setBookingValue("");
      setBookingPaid("");
      setShowBookingModal(false);
    } catch (err) {
      alert("Error saving booking: " + err);
    }
  };

  // Find non-booked leads to display in "Record New Booking" selector
  const availableLeadsForBooking = leads.filter(l => l.leadStatus !== "Booked" && l.leadStatus !== "Lost");

  return (
    <div className="space-y-6 font-sans" id="cash-flow-view">
      
      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Ledger actions card */}
        <div className="bg-gradient-to-br from-slate-900 to-indigo-950 border border-slate-800/80 rounded-2xl p-6 text-white flex flex-col justify-between space-y-5 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl group-hover:bg-indigo-500/20 transition-all" />
          <div>
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono text-[9px] font-bold uppercase px-2.5 py-1 rounded-full flex items-center gap-1 w-fit">
              <Sparkles className="w-3 h-3 text-indigo-400" />
              Revenue Control Desk
            </span>
            <h3 className="text-base font-bold text-white font-display mt-3">B2B Financial Operations Ledger</h3>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              Admin roles can manage customer balance sheets, register milestone payment checks, and record new purchases.
            </p>
          </div>
          <div className="flex gap-2 relative z-10">
            <button
              onClick={() => {
                if (!isAdmin) {
                  alert("Credential Lock: Changing follow-up ledger data requires Tenant Admin status.");
                  return;
                }
                setShowBookingModal(true);
              }}
              className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-sm shadow-indigo-600/20"
              id="record-booking-btn"
            >
              <Plus className="w-3.5 h-3.5" /> Book Deal
            </button>
            <button
              onClick={() => {
                if (!isAdmin) {
                  alert("Credential Lock: Logging payments is restricted to Tenant Admin profiles.");
                  return;
                }
                setShowPayModal(true);
              }}
              className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700/60 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5"
              id="record-payment-btn"
            >
              <DollarSign className="w-3.5 h-3.5" /> Log Installment
            </button>
          </div>
        </div>

        {/* Ledger stats */}
        {bookings.length > 0 && (() => {
          const totalValue = bookings.reduce((sum, b) => sum + b.dealValue, 0);
          const totalReceived = bookings.reduce((sum, b) => sum + b.amountReceived, 0);
          const totalBalance = bookings.reduce((sum, b) => sum + b.balanceDue, 0);
          const overallPercent = Math.min(100, Math.round((totalReceived / totalValue) * 100)) || 0;

          return (
            <>
              <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80 p-6 flex flex-col justify-between">
                <div>
                  <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Funds Collection Rate</div>
                  <div className="text-3xl font-black text-slate-950 dark:text-white mt-1.5 font-display tracking-tight">
                    {overallPercent}%
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                    Aggregated capital collected across all multi-tenant sales contracts inside this namespace.
                  </p>
                </div>
                {/* Visual indicator bar */}
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden mt-4">
                  <div className="bg-indigo-600 h-full transition-all" style={{ width: `${overallPercent}%` }} />
                </div>
              </div>

              <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80 p-6 flex flex-col justify-between">
                <div>
                  <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Outstanding Accounts Receivable</div>
                  <div className="text-3xl font-black text-slate-950 dark:text-white mt-1.5 font-display tracking-tight">
                    INR {(totalBalance / 10000000).toFixed(2)} Cr
                  </div>
                  <div className="text-[11px] mt-2 text-slate-500 dark:text-slate-400 flex items-center gap-1.5 font-mono">
                    <span>Invoiced Value:</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">INR {(totalValue / 10000000).toFixed(2)} Cr</span>
                  </div>
                </div>
                <div className="text-[10px] text-rose-700 dark:text-rose-400 font-semibold bg-rose-50 dark:bg-rose-950/10 border border-rose-100 dark:border-rose-900/30 p-2.5 rounded-xl flex items-center gap-2 mt-4 font-mono">
                  <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                  <span>Monitor due dates to avoid contract breaching triggers.</span>
                </div>
              </div>
            </>
          );
        })()}
      </div>

      {/* 2. SALES LEDGER TABLE */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80 overflow-hidden">
        <div className="px-6 py-5 bg-slate-50 dark:bg-slate-950/40 border-b border-slate-100 dark:border-slate-800/80">
          <h2 className="text-base font-bold text-slate-950 dark:text-white font-display">Post-Sale Invoicing Ledger</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">Track balance sheets, milestone installment plans, and transaction clearances.</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300 border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-950/60 text-slate-700 dark:text-slate-400 font-bold uppercase text-[10px] border-b border-slate-200/50 dark:border-slate-800/50">
                <th className="px-6 py-4">Property Unit</th>
                <th className="px-6 py-4">Invoiced Value</th>
                <th className="px-6 py-4">Funds Collected</th>
                <th className="px-6 py-4">Invoiced Progress</th>
                <th className="px-6 py-4">Outstanding Balance</th>
                <th className="px-6 py-4">Deadline Date</th>
                <th className="px-6 py-4">Billing Status</th>
              </tr>
            </thead>
            <tbody>
              {bookings.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400 italic dark:text-slate-500">
                    No active sales logged. Allocate a lead and update their status to "Booked" or record a booking above.
                  </td>
                </tr>
              ) : (
                bookings.map((booking) => {
                  const collectionRate = Math.min(100, Math.round((booking.amountReceived / booking.dealValue) * 100)) || 0;
                  const dueDateObj = new Date(booking.nextDueDate);

                  return (
                    <tr key={booking.bookingId} className="border-b border-slate-100 dark:border-slate-800/80 hover:bg-slate-50/50 dark:hover:bg-slate-850/30 transition-colors">
                      <td className="px-6 py-4">
                        <div className="font-bold text-slate-900 dark:text-white text-sm">{booking.propertyName}</div>
                        <div className="text-[10px] text-slate-400 dark:text-slate-500 font-mono mt-0.5">Unit Number: {booking.unitNumber}</div>
                      </td>
                      <td className="px-6 py-4 font-mono font-bold text-slate-700 dark:text-slate-300">
                        INR {(booking.dealValue / 100000).toFixed(1)} Lakhs
                      </td>
                      <td className="px-6 py-4 font-mono font-bold text-slate-950 dark:text-white">
                        INR {(booking.amountReceived / 100000).toFixed(1)} Lakhs
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-20 bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                            <div className="bg-indigo-600 h-full" style={{ width: `${collectionRate}%` }} />
                          </div>
                          <span className="font-mono text-[10px] font-bold text-slate-900 dark:text-white">{collectionRate}%</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-mono font-bold text-rose-600 dark:text-rose-400">
                        INR {(booking.balanceDue / 100000).toFixed(1)} Lakhs
                      </td>
                      <td className="px-6 py-4 font-mono text-slate-600 dark:text-slate-400">
                        {dueDateObj.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                            booking.paymentStatus === "Fully Paid"
                              ? "bg-emerald-100 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-400 border-emerald-200/20"
                              : booking.paymentStatus === "Balance Overdue"
                              ? "bg-rose-100 dark:bg-rose-950/40 text-rose-800 dark:text-rose-400 border-rose-200/20 animate-pulse"
                              : "bg-amber-100 dark:bg-amber-950/40 text-amber-800 dark:text-amber-400 border-amber-200/20"
                          }`}
                        >
                          {booking.paymentStatus === "Balance Overdue" ? "🔴 OVERDUE" : booking.paymentStatus}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. LOG PAYMENT MODAL */}
      {showPayModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="px-6 py-5 bg-slate-50 dark:bg-slate-950 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-slate-950 dark:text-white text-base font-display">Record Client Installment</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Record payments to adjust outstanding balances</p>
              </div>
              <button 
                onClick={() => setShowPayModal(false)} 
                className="text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 p-1.5 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleRecordPayment} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Target Sales Contract</label>
                <select
                  value={selectedBookingId}
                  onChange={(e) => setSelectedBookingId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white"
                  required
                >
                  <option value="">-- Choose Contract Unit --</option>
                  {bookings.filter(b => b.balanceDue > 0).map((b) => (
                    <option key={b.bookingId} value={b.bookingId}>
                      {b.propertyName} (Unit: {b.unitNumber}) - Bal: INR {b.balanceDue.toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Amount Received (INR)</label>
                <input
                  type="number"
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  placeholder="e.g. 500000"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Method of Remittance</label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                >
                  <option value="Wire Transfer">Wire Transfer / Bank RTGS</option>
                  <option value="Cheque">Milestone Cheque</option>
                  <option value="Demand Draft">Demand Draft</option>
                  <option value="UPI">Corporate UPI / Card</option>
                </select>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button type="button" onClick={() => setShowPayModal(false)} className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold rounded-xl">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-sm shadow-indigo-600/10">Post Installment</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. MOCK BOOK DEALS MODAL */}
      {showBookingModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="px-6 py-5 bg-slate-50 dark:bg-slate-950 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-slate-950 dark:text-white text-base font-display">Confirm Unit Booking & Allotment</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Record a confirmed purchase sale for a leads client profile</p>
              </div>
              <button 
                onClick={() => setShowBookingModal(false)} 
                className="text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 p-1.5 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateBooking} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Target CRM Lead</label>
                <select
                  value={bookingLeadId}
                  onChange={(e) => setBookingLeadId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  required
                >
                  <option value="">-- Choose Client Lead --</option>
                  {availableLeadsForBooking.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.customerName} ({l.project} - Budget: INR {l.budget.toLocaleString()})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Development Property Name</label>
                <input
                  type="text"
                  value={bookingProject}
                  onChange={(e) => setBookingProject(e.target.value)}
                  placeholder="e.g. Skyline Aurum Tower"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Allotted Unit Number</label>
                <input
                  type="text"
                  value={bookingUnit}
                  onChange={(e) => setBookingUnit(e.target.value)}
                  placeholder="e.g. 1404-B"
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Agreed Deal Price (INR)</label>
                  <input
                    type="number"
                    value={bookingValue}
                    onChange={(e) => setBookingValue(e.target.value)}
                    placeholder="e.g. 18500000"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Down Payment Paid (INR)</label>
                  <input
                    type="number"
                    value={bookingPaid}
                    onChange={(e) => setBookingPaid(e.target.value)}
                    placeholder="e.g. 2000000"
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button type="button" onClick={() => setShowBookingModal(false)} className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold rounded-xl">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-sm shadow-indigo-600/10">Confirm Contract Allotment</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
