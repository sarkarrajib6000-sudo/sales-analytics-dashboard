import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { AlertTriangle, Clock, Calendar, CheckSquare, PhoneCall, Trash2, Edit3, X, Eye, Plus, Sparkles } from "lucide-react";
import { Lead } from "../types";
import CreateLeadModal from "./CreateLeadModal";

export default function LeadWorkflow() {
  const {
    leads,
    simulatedUsers,
    currentUser,
    updateLeadStatus,
    updateLeadFollowUp,
    deleteLead
  } = useApp();

  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [showLogModal, setShowLogModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [updateNotes, setUpdateNotes] = useState("");
  const [nextFollowUpDate, setNextFollowUpDate] = useState("");
  const [updateStatus, setUpdateStatus] = useState<Lead["leadStatus"] | "">("");

  // Role Filtering: Executives see only their assigned leads. Admins/Managers see all.
  const isExec = currentUser?.role === "Executive";
  const filteredLeads = leads.filter((lead) => {
    if (isExec) {
      return lead.assignedExecutiveId === currentUser?.userId;
    }
    return true;
  });

  // Filter out Escalated/Overdue leads for Manager Alerts Panel
  const escalatedLeads = filteredLeads.filter(
    (lead) => lead.automationStatus === "Escalated" && lead.leadStatus !== "Booked" && lead.leadStatus !== "Lost"
  );

  const handleOpenLogModal = (lead: Lead) => {
    setSelectedLead(lead);
    setUpdateNotes("");
    setUpdateStatus(lead.leadStatus);
    
    // Default next follow-up date: tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    setNextFollowUpDate(tomorrow.toISOString().split("T")[0]);
    
    setShowLogModal(true);
  };

  const handleSaveUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLead) return;

    try {
      // 1. Update status if changed
      if (updateStatus && updateStatus !== selectedLead.leadStatus) {
        await updateLeadStatus(selectedLead.id, updateStatus as any, updateNotes);
      }

      // 2. Set next follow up date and clear escalation status
      if (nextFollowUpDate) {
        const nextDateTime = new Date(nextFollowUpDate).toISOString();
        await updateLeadFollowUp(selectedLead.id, nextDateTime, updateNotes || `Completed update. Rescheduled follow-up.`);
      }

      setShowLogModal(false);
      setSelectedLead(null);
    } catch (err) {
      console.error(err);
      alert("Error logging follow-up: " + err);
    }
  };

  const getSLAUrgencyBadge = (lead: Lead) => {
    const nextDate = new Date(lead.nextFollowUpDate);
    const now = new Date();
    const diffDays = (nextDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);

    if (lead.leadStatus === "Booked") {
      return (
        <span className="inline-flex items-center gap-1 bg-emerald-100 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-400 text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-900/50">
          🎉 Closed Booked
        </span>
      );
    }
    if (lead.leadStatus === "Lost") {
      return (
        <span className="inline-flex items-center gap-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full border border-slate-200 dark:border-slate-700">
          Lost Deal
        </span>
      );
    }

    if (diffDays < -3) {
      return (
        <span className="inline-flex items-center gap-1 bg-rose-100 dark:bg-rose-950/40 text-rose-800 dark:text-rose-400 text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full border border-rose-200 dark:border-rose-900/50 animate-pulse">
          🔴 CRITICAL OVERDUE
        </span>
      );
    } else if (diffDays < 0) {
      return (
        <span className="inline-flex items-center gap-1 bg-amber-100 dark:bg-amber-950/40 text-amber-800 dark:text-amber-400 text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full border border-amber-200 dark:border-amber-900/50">
          🟡 Follow-up Due
        </span>
      );
    } else {
      return (
        <span className="inline-flex items-center gap-1 bg-emerald-50 dark:bg-emerald-950/10 text-emerald-800 dark:text-emerald-400 text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full border border-emerald-100 dark:border-emerald-900/30">
          🟢 On Track
        </span>
      );
    }
  };

  return (
    <div className="space-y-6 font-sans" id="lead-workflow-view">
      
      {/* 1. MANAGER ALERTS PANEL (Dynamic Escalations) */}
      {!isExec && escalatedLeads.length > 0 && (
        <div className="bg-rose-50 dark:bg-rose-950/10 border border-rose-200 dark:border-rose-900/40 rounded-xl p-5 shadow-sm space-y-3" id="manager-alerts-panel">
          <div className="flex items-center gap-2 text-rose-800 dark:text-rose-400">
            <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-400 flex-shrink-0 animate-bounce" />
            <h3 className="font-bold text-sm tracking-tight font-display uppercase">
              Urgent SLA Breach Alert Desk ({escalatedLeads.length} Escalated Leads)
            </h3>
          </div>
          <p className="text-xs text-rose-700 dark:text-rose-300 leading-normal max-w-3xl">
            The following lead records have exceeded their scheduled follow-up dates by more than 3 days. System workflows have automatically escalated their status to draw immediate manager intervention and re-routing.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-1">
            {escalatedLeads.map((lead) => {
              const agent = simulatedUsers.find(u => u.userId === lead.assignedExecutiveId);
              const daysOverdue = Math.floor((new Date().getTime() - new Date(lead.nextFollowUpDate).getTime()) / (1000 * 60 * 60 * 24));
              
              return (
                <div key={lead.id} className="bg-white dark:bg-slate-900 rounded-lg p-3.5 border border-rose-200 dark:border-rose-900/30 shadow-xs flex flex-col justify-between space-y-3 text-xs relative">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-bold text-slate-900 dark:text-slate-100 text-sm">{lead.customerName}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">Project: {lead.project} ({lead.unitType})</div>
                    </div>
                    <span className="bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-400 font-bold px-1.5 py-0.5 rounded text-[10px]">
                      {daysOverdue}d overdue
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center text-[11px] pt-1.5 border-t border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-300">
                    <div>Agent: <span className="font-semibold text-slate-800 dark:text-slate-200">{agent ? agent.name : "Unassigned"}</span></div>
                    <div className="font-bold text-indigo-600 dark:text-indigo-400">INR {(lead.budget/100000).toFixed(1)}L Budget</div>
                  </div>

                  <button
                    onClick={() => handleOpenLogModal(lead)}
                    className="w-full mt-2 py-1.5 bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold text-[10px] rounded-md uppercase transition-colors"
                  >
                    Take Action
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. MAIN LEADS WORKFLOW MONITOR */}
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xs border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-950/40 border-b border-slate-200 dark:border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white font-display">Active Lead Pipeline & SLA Monitor</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isExec
                ? "Showing only leads allocated to your private dashboard. Keep follow-ups green to satisfy SLAs."
                : "Consolidated multi-tenant sales pipeline tracking follow-ups, statuses, and agent workloads."}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => {
                const headers = ["Customer Name", "Mobile", "City", "Budget", "Project", "Unit Type", "Lead Source", "Lead Status"];
                const data = filteredLeads.map(l => [l.customerName, l.mobileNumber, l.city, l.budget, l.project, l.unitType, l.leadSource, l.leadStatus]);
                const csvContent = [headers, ...data].map(row => row.join(",")).join("\n");
                const blob = new Blob([csvContent], { type: 'text/csv' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'leads.csv';
                a.click();
                URL.revokeObjectURL(url);
              }}
              className="px-3.5 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 font-bold text-xs rounded-lg flex items-center gap-2 transition-all shadow-xs duration-150"
            >
              Export CSV
            </button>
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white font-bold text-xs rounded-lg flex items-center gap-2 transition-all shadow-sm shadow-indigo-600/10 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 duration-150"
            >
              <Plus className="w-4 h-4" />
              Add New Lead
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300 border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-950/60 text-slate-700 dark:text-slate-400 font-bold uppercase text-[10px] border-b border-slate-200 dark:border-slate-800">
                <th className="px-6 py-3.5">Customer Details</th>
                <th className="px-6 py-3.5">Property Interest</th>
                <th className="px-6 py-3.5">Allocated Agent</th>
                <th className="px-6 py-3.5">Inquiry Status</th>
                <th className="px-6 py-3.5">Next Scheduled Contact</th>
                <th className="px-6 py-3.5">SLA Status</th>
                <th className="px-6 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredLeads.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400 italic dark:text-slate-500">
                    No leads matching criteria found. Try triggering the inbound webhook tester.
                  </td>
                </tr>
              ) : (
                filteredLeads.map((lead) => {
                  const agent = simulatedUsers.find(u => u.userId === lead.assignedExecutiveId);
                  const nextDateObj = new Date(lead.nextFollowUpDate);
                  
                  return (
                    <tr key={lead.id} className="border-b border-slate-100 dark:border-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-850/40 transition-colors">
                      {/* Name & source */}
                      <td className="px-6 py-4">
                        <div className="font-bold text-slate-900 dark:text-slate-100 text-sm">{lead.customerName}</div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1 font-mono mt-1">
                          <span>{lead.mobileNumber}</span>
                          <span>•</span>
                          <span className="font-sans bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-1.5 py-0.2 rounded">
                            {lead.leadSource}
                          </span>
                        </div>
                      </td>

                      {/* Project, Budget, unit */}
                      <td className="px-6 py-4">
                        <div className="font-semibold text-slate-800 dark:text-slate-200">{lead.project}</div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono mt-0.5">
                          {lead.unitType} • INR {(lead.budget / 10000000).toFixed(2)} Cr
                        </div>
                      </td>

                      {/* Allocated Agent */}
                      <td className="px-6 py-4">
                        <span className="font-medium text-slate-700 dark:text-slate-200">
                          {agent ? agent.name.split(" ")[0] : "System Pool"}
                        </span>
                        <div className="text-[9px] text-slate-400 dark:text-slate-500 font-mono uppercase mt-0.5">{lead.city}</div>
                      </td>

                      {/* Status pill */}
                      <td className="px-6 py-4">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase ${
                            lead.leadStatus === "Booked"
                              ? "bg-emerald-100 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-400 border border-emerald-200/30"
                              : lead.leadStatus === "Site Visit Completed"
                              ? "bg-indigo-100 dark:bg-indigo-950/40 text-indigo-800 dark:text-indigo-400 border border-indigo-200/30"
                              : lead.leadStatus === "Negotiation"
                              ? "bg-amber-100 dark:bg-amber-950/40 text-amber-800 dark:text-amber-400 border border-amber-200/30"
                              : lead.leadStatus === "Lost"
                              ? "bg-slate-150 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200/20"
                              : "bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200/20"
                          }`}
                        >
                          {lead.leadStatus}
                        </span>
                      </td>

                      {/* Next follow up date */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5 font-mono text-slate-700 dark:text-slate-300">
                          <Clock className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                          <span>{nextDateObj.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}</span>
                        </div>
                        {lead.notes && (
                          <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 max-w-[180px] truncate" title={lead.notes}>
                            📝 {lead.notes}
                          </div>
                        )}
                      </td>

                      {/* SLA Urgency badge */}
                      <td className="px-6 py-4">
                        {getSLAUrgencyBadge(lead)}
                      </td>

                      {/* Update Action triggers */}
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenLogModal(lead)}
                            className="px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-400 font-bold rounded-lg flex items-center gap-1.5 transition-all text-[11px] border border-indigo-100/50 dark:border-indigo-900/40 duration-150"
                          >
                            <PhoneCall className="w-3.5 h-3.5 shrink-0" />
                            Log Touchpoint
                          </button>
                          {currentUser?.role === "Admin" && (
                            <button
                              onClick={() => {
                                if (confirm(`Are you sure you want to delete lead: ${lead.customerName}?`)) {
                                  deleteLead(lead.id);
                                }
                              }}
                              className="p-2 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-rose-600 dark:text-rose-400 rounded-lg border border-transparent hover:border-rose-150 dark:hover:border-rose-900/50 transition-all duration-150"
                              title="Delete Lead"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. LOG TOUCHPOINT MODAL */}
      {showLogModal && selectedLead && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-slate-950 dark:text-white text-base font-display">Log Follow-up & Touchpoint</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Client Profile: {selectedLead.customerName}</p>
              </div>
              <button
                onClick={() => {
                  setShowLogModal(false);
                  setSelectedLead(null);
                }}
                className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg text-slate-500 dark:text-slate-400 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveUpdate} className="p-6 space-y-4 text-xs">
              {/* Status Update */}
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Inquiry Status</label>
                <select
                  value={updateStatus}
                  onChange={(e) => setUpdateStatus(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors"
                  required
                >
                  <option value="New">New (Inbound)</option>
                  <option value="Connected">Connected (First Contact)</option>
                  <option value="Follow-up">Follow-up Scheduled</option>
                  <option value="Negotiation">In Negotiation</option>
                  <option value="Site Visit Scheduled">Site Visit Booked</option>
                  <option value="Site Visit Completed">Site Visit Done</option>
                  <option value="Booked">Booked (Allotment Done)</option>
                  <option value="Lost">Lost Deal</option>
                </select>
              </div>

              {/* Next Scheduled Contact */}
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">
                  Reschedule Follow-up Date (Extends SLA Target)
                </label>
                <input
                  type="date"
                  value={nextFollowUpDate}
                  onChange={(e) => setNextFollowUpDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors"
                  required
                />
                <span className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 block">
                  Selecting a future date resets active escalation states back to 🟢 On Track.
                </span>
              </div>

              {/* CRM Interaction Notes */}
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Sales Interaction Notes</label>
                <textarea
                  value={updateNotes}
                  onChange={(e) => setUpdateNotes(e.target.value)}
                  placeholder="e.g. Completed a phone call. Sandeep requested brochure for phase 2. Rescheduling site tour to Sunday."
                  className="w-full h-24 px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-sm bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors"
                  required
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-3.5 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowLogModal(false);
                    setSelectedLead(null);
                  }}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white font-bold rounded-lg shadow-sm transition-all"
                >
                  Save Notes & SLA Extension
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {showCreateModal && (
        <CreateLeadModal onClose={() => setShowCreateModal(false)} />
      )}
    </div>
  );
}
