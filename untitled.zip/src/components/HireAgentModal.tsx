import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { X, CheckCircle } from "lucide-react";
import { UserRole } from "../types";
import { motion, AnimatePresence } from "motion/react";

export default function HireAgentModal({ onClose }: { onClose: () => void }) {
  const { addAgent } = useApp();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    role: "Executive" as UserRole,
    kpiTarget: 0,
  });
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addAgent(formData);
    setIsSuccess(true);
    setTimeout(() => onClose(), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200 relative">
        <AnimatePresence>
          {isSuccess && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute inset-0 bg-white dark:bg-slate-900 z-10 flex flex-col items-center justify-center p-6 text-center"
            >
              <CheckCircle className="w-16 h-16 text-emerald-500 mb-4" />
              <h3 className="text-xl font-bold text-slate-950 dark:text-white font-display">Agent Hired Successfully!</h3>
              <p className="text-slate-500 dark:text-slate-400 mt-1">The new team member has been added to the database.</p>
            </motion.div>
          )}
        </AnimatePresence>
        
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
          <h3 className="font-bold text-slate-950 dark:text-white text-base font-display">Hire New Agent</h3>
          <button onClick={onClose} className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg text-slate-500 dark:text-slate-400 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Name</label>
            <input 
              type="text" 
              required 
              placeholder="e.g. Ramesh Kumar"
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
              onChange={(e) => setFormData({...formData, name: e.target.value})} 
            />
          </div>
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Email</label>
            <input 
              type="email" 
              required 
              placeholder="e.g. ramesh@company.com"
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
              onChange={(e) => setFormData({...formData, email: e.target.value})} 
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Role</label>
              <select 
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
                onChange={(e) => setFormData({...formData, role: e.target.value as UserRole})}
              >
                <option value="Executive">Executive</option>
                <option value="Manager">Manager</option>
                <option value="Admin">Admin</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1">Starting Target (Bookings)</label>
              <input 
                type="number" 
                required 
                placeholder="e.g. 5"
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
                onChange={(e) => setFormData({...formData, kpiTarget: parseInt(e.target.value)})} 
              />
            </div>
          </div>
          <button type="submit" className="w-full mt-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow-sm transition-all text-xs">
            Hire Agent & Initialize KPIs
          </button>
        </form>
      </div>
    </div>
  );
}
