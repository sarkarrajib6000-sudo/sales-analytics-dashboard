import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { X, User, Phone, MapPin, Building, Percent, Sparkles, DollarSign, Eye } from "lucide-react";
import { Lead } from "../types";

export default function CreateLeadModal({ onClose }: { onClose: () => void }) {
  const { addLead, simulatedUsers } = useApp();
  const [formData, setFormData] = useState<Omit<Lead, "id" | "tenantId" | "automationStatus">>({
    leadDate: new Date().toISOString().split("T")[0],
    customerName: "",
    mobileNumber: "",
    city: "Mumbai",
    budget: 5000000,
    project: "Skyline Aurum Tower",
    unitType: "2 BHK",
    leadSource: "Website",
    assignedExecutiveId: simulatedUsers[0]?.userId || "",
    leadStatus: "New",
    nextFollowUpDate: new Date(Date.now() + 86400000).toISOString().split("T")[0],
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await addLead(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200/60 dark:border-slate-800/80 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-5 bg-slate-50 dark:bg-slate-950 border-b border-slate-100 dark:border-slate-850 flex justify-between items-center">
          <div>
            <h3 className="font-bold text-slate-950 dark:text-white text-base font-display">Ingest New Qualified Lead</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">Initialize real-time routing engines and assign sales officers instantly.</p>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg text-slate-500 dark:text-slate-400 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          
          {/* Customer Name */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px]">Customer Name</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400"><User className="w-4 h-4" /></span>
              <input 
                type="text" 
                required 
                placeholder="e.g. Anand Sharma"
                className="w-full pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
                onChange={(e) => setFormData({...formData, customerName: e.target.value})} 
              />
            </div>
          </div>

          {/* Mobile Number */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px]">Mobile Number</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400"><Phone className="w-4 h-4" /></span>
              <input 
                type="text" 
                required 
                placeholder="e.g. +91 9876543210"
                className="w-full pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
                onChange={(e) => setFormData({...formData, mobileNumber: e.target.value})} 
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Budget */}
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px]">Budget (INR)</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400"><DollarSign className="w-4 h-4" /></span>
                <input 
                  type="number" 
                  required 
                  placeholder="e.g. 7500000"
                  className="w-full pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors font-mono" 
                  onChange={(e) => setFormData({...formData, budget: parseInt(e.target.value) || 0})} 
                />
              </div>
            </div>

            {/* Lead Source */}
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px]">Lead Source</label>
              <select 
                value={formData.leadSource}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
                onChange={(e) => setFormData({...formData, leadSource: e.target.value})}
              >
                <option value="Website">Website Inquiries</option>
                <option value="Facebook">Facebook Lead Ads</option>
                <option value="99acres">99acres Portal</option>
                <option value="Walk-in">Walk-in Visit</option>
              </select>
            </div>
          </div>

          {/* Geographical & Property Parameters */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px]">City</label>
              <select 
                value={formData.city}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
                onChange={(e) => setFormData({...formData, city: e.target.value})}
              >
                <option value="Mumbai">Mumbai</option>
                <option value="Bangalore">Bangalore</option>
                <option value="Pune">Pune</option>
                <option value="Delhi NCR">Delhi NCR</option>
              </select>
            </div>
            
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px]">Project Interst</label>
              <select 
                value={formData.project}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
                onChange={(e) => setFormData({...formData, project: e.target.value})}
              >
                <option value="Skyline Aurum Tower">Skyline Aurum</option>
                <option value="Horizon Heights">Horizon Heights</option>
                <option value="PropFlow Regency">PropFlow Regency</option>
                <option value="Oasis Greens">Oasis Greens</option>
                <option value="Royal Palms">Royal Palms</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px]">Unit Type</label>
              <select 
                value={formData.unitType}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
                onChange={(e) => setFormData({...formData, unitType: e.target.value})}
              >
                <option value="1 BHK">1 BHK</option>
                <option value="2 BHK">2 BHK</option>
                <option value="3 BHK">3 BHK</option>
                <option value="4 BHK">4 BHK</option>
                <option value="Penthouse">Penthouse</option>
                <option value="Studio">Studio</option>
              </select>
            </div>
          </div>

          {/* Agent Selection */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px]">Allocate Sales Agent</label>
            <select 
              required 
              value={formData.assignedExecutiveId}
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors" 
              onChange={(e) => setFormData({...formData, assignedExecutiveId: e.target.value})}
            >
              <option value="">Select Agent...</option>
              {simulatedUsers.map(u => <option key={u.userId} value={u.userId}>{u.name} ({u.role})</option>)}
            </select>
          </div>
          
          {/* Action buttons */}
          <div className="pt-5 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
            <button 
              type="button" 
              onClick={onClose} 
              className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-sm shadow-indigo-600/10 transition-all flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Add Lead to Pipeline
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
