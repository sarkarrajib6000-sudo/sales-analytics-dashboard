import React, { useMemo, useState } from "react";
import { useApp } from "../context/AppContext";
import { Trophy, Star, TrendingUp, Award, Zap, Plus, UserPlus, ShieldAlert, CheckCircle, Mail, Target, Briefcase, Sparkles, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { UserRole } from "../types";

export default function TeamScorecard() {
  const { leads, bookings, simulatedUsers, logs, addAgent } = useApp();
  
  // Inline Form States
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<UserRole>("Executive");
  const [kpiTarget, setKpiTarget] = useState<number>(5);
  
  // Toast Notification States
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  const executives = simulatedUsers.filter(u => u.role === "Executive");

  // Dynamic Scoreboard Aggregator based on active database snapshot
  const scores = useMemo(() => {
    return executives.map((exec) => {
      // 1. Find leads assigned to this executive
      const execLeads = leads.filter(l => l.assignedExecutiveId === exec.userId);
      
      // 2. Count active leads (not Booked, not Lost)
      const activeLeadsCount = execLeads.filter(l => l.leadStatus !== "Booked" && l.leadStatus !== "Lost").length;
      
      // 3. Count completed/scheduled site visits
      const siteVisitsCount = execLeads.filter(
        l => l.leadStatus === "Site Visit Completed" || l.leadStatus === "Site Visit Scheduled"
      ).length;

      // 4. Bookings and Revenue
      const execLeadIds = execLeads.map(l => l.id);
      const execBookings = bookings.filter(b => execLeadIds.includes(b.leadId));
      const bookingsCount = execBookings.length;
      const totalRevenue = execBookings.reduce((sum, b) => sum + b.dealValue, 0);

      // 5. Calls Made (calculated as basic baseline + logged touchpoints from logs)
      const loggedUpdatesCount = logs.filter(
        log => log.eventType === "Followup Updated" && execLeadIds.includes(log.leadId)
      ).length;
      
      // Baseline 18 calls + logged calls
      const totalCalls = 18 + loggedUpdatesCount;

      return {
        id: exec.userId,
        name: exec.name,
        email: exec.email,
        activeLeads: activeLeadsCount,
        callsMade: totalCalls,
        siteVisits: siteVisitsCount,
        bookings: bookingsCount,
        revenue: totalRevenue
      };
    }).sort((a, b) => b.bookings - a.bookings || b.revenue - a.revenue); // Auto sorting by closings
  }, [executives, leads, bookings, logs]);

  // Total summary statistics
  const totals = useMemo(() => {
    return scores.reduce(
      (acc, s) => {
        acc.leads += s.activeLeads;
        acc.calls += s.callsMade;
        acc.visits += s.siteVisits;
        acc.bookings += s.bookings;
        acc.revenue += s.revenue;
        return acc;
      },
      { leads: 0, calls: 0, visits: 0, bookings: 0, revenue: 0 }
    );
  }, [scores]);

  const handleHireSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;

    addAgent({
      name,
      email,
      role,
      kpiTarget
    });

    setToastMessage(`Welcome aboard, ${name}! Dynamic KPI targets initialized at ${kpiTarget} closings.`);
    setShowToast(true);

    // Reset Form
    setName("");
    setEmail("");
    setRole("Executive");
    setKpiTarget(5);

    // Auto dismiss toast
    setTimeout(() => {
      setShowToast(false);
    }, 4000);
  };

  return (
    <div className="space-y-6 font-sans relative" id="team-scorecard-view">
      
      {/* Dynamic Success Toast */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className="fixed top-6 right-6 z-50 bg-slate-900 border border-emerald-500/30 text-white rounded-xl shadow-xl p-4 flex items-center gap-3.5 max-w-sm"
          >
            <div className="bg-emerald-500/20 text-emerald-400 p-2 rounded-lg border border-emerald-500/30">
              <CheckCircle className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-bold font-display text-emerald-400">Onboarding Sync Successful</div>
              <p className="text-[11px] text-slate-300 leading-normal mt-0.5">{toastMessage}</p>
            </div>
            <button 
              onClick={() => setShowToast(false)} 
              className="text-slate-400 hover:text-slate-200 transition-colors self-start"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dynamic Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Active Pipelines Allocated", val: totals.leads, desc: "Across operations desk", accent: "text-indigo-600 dark:text-indigo-400" },
          { label: "Visits Done", val: totals.visits, desc: "Live physical tours completed", accent: "text-indigo-950 dark:text-indigo-300" },
          { label: "Closings Logged", val: totals.bookings, desc: "Units registered", accent: "text-emerald-600 dark:text-emerald-400" },
          { label: "Gross Cleared Value", val: `INR ${(totals.revenue / 10000000).toFixed(2)} Cr`, desc: "Total asset volume realized", accent: "text-indigo-600 dark:text-indigo-400" },
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80">
            <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">{stat.label}</span>
            <div className={`text-2xl font-black mt-2 font-display ${stat.accent}`}>{stat.val}</div>
            <span className="text-[10px] text-slate-400 block mt-2 font-mono">● {stat.desc}</span>
          </div>
        ))}
      </div>

      {/* Leaderboard Grid */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80 overflow-hidden">
        <div className="px-6 py-5 bg-slate-50 dark:bg-slate-950/40 border-b border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-slate-950 dark:text-white font-display">Executive Performance Leaderboard</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Live operational scoreboard sorted dynamically by closed bookings and revenue.</p>
          </div>
          <div className="flex items-center gap-2 self-start sm:self-center">
            <span className="bg-indigo-50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-400 text-[10px] font-bold px-3 py-1.5 rounded-lg border border-indigo-100/55 dark:border-indigo-900/50 flex items-center gap-1.5">
              <Trophy className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 animate-bounce" />
              Rank-Sorted Tracker
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300 border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-950/60 text-slate-700 dark:text-slate-400 font-bold uppercase text-[10px] border-b border-slate-200/50 dark:border-slate-800/50">
                <th className="px-6 py-4 text-center w-16">Rank</th>
                <th className="px-6 py-4">Executive Name</th>
                <th className="px-6 py-4 text-center">Active Leads Pipeline</th>
                <th className="px-6 py-4 text-center">CRM Touchpoints Logged</th>
                <th className="px-6 py-4 text-center">Site Tours Completed</th>
                <th className="px-6 py-4 text-center">Confirmed Sales</th>
                <th className="px-6 py-4 text-right">Revenue Generated</th>
              </tr>
            </thead>
            <tbody>
              {scores.map((score, index) => {
                const isWinner = index === 0 && score.bookings > 0;
                
                return (
                  <tr key={score.id} className={`border-b border-slate-100 dark:border-slate-800/80 hover:bg-slate-50/50 dark:hover:bg-slate-850/30 transition-colors ${isWinner ? "bg-amber-50/10 dark:bg-amber-950/10" : ""}`}>
                    {/* Rank Badge */}
                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center justify-center">
                        {index === 0 ? (
                          <div className="bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-300 font-black rounded-full w-6 h-6 flex items-center justify-center border border-amber-200 dark:border-amber-800 text-xs" title="Top Closer">
                            🥇
                          </div>
                        ) : index === 1 ? (
                          <div className="bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-300 font-black rounded-full w-6 h-6 flex items-center justify-center border border-slate-300 dark:border-slate-600 text-xs">
                            🥈
                          </div>
                        ) : (
                          <span className="font-bold text-slate-400 dark:text-slate-500 font-mono text-sm">{index + 1}</span>
                        )}
                      </div>
                    </td>

                    {/* Name & details */}
                    <td className="px-6 py-4">
                      <div className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                        {score.name}
                        {isWinner && <Award className="w-4 h-4 text-amber-500 animate-pulse" />}
                      </div>
                      <div className="text-[10px] text-slate-400 dark:text-slate-500 font-mono mt-0.5">{score.email}</div>
                    </td>

                    {/* Active Leads */}
                    <td className="px-6 py-4 text-center text-slate-700 dark:text-slate-300 font-semibold font-mono text-sm">
                      {score.activeLeads}
                    </td>

                    {/* Touchpoints */}
                    <td className="px-6 py-4 text-center text-slate-700 dark:text-slate-300 font-semibold font-mono text-sm">
                      {score.callsMade}
                    </td>

                    {/* Site Visits */}
                    <td className="px-6 py-4 text-center text-slate-700 dark:text-slate-300 font-semibold font-mono text-sm">
                      {score.siteVisits}
                    </td>

                    {/* Confirmed sales */}
                    <td className="px-6 py-4 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full font-black font-mono text-xs ${score.bookings > 0 ? "bg-emerald-100 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-400 border border-emerald-200/20" : "bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-600"}`}>
                        {score.bookings}
                      </span>
                    </td>

                    {/* Revenue */}
                    <td className="px-6 py-4 text-right font-bold text-slate-900 dark:text-slate-100 text-sm font-mono">
                      INR {(score.revenue / 100000).toFixed(1)} Lakhs
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Inline 'Hire New Agent' Talent Placement Desk */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80 p-6">
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-5">
          <UserPlus className="w-5 h-5 text-indigo-500" />
          <div>
            <h3 className="font-bold text-slate-950 dark:text-white text-sm font-display">Talent Placement & Growth Desk</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">Instantly onboard new sales executives, authorize system accounts, and set baseline closing targets.</p>
          </div>
        </div>

        <form onSubmit={handleHireSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end text-xs">
          
          {/* Agent Name */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px] flex items-center gap-1">
              <span>Agent Name</span>
            </label>
            <input 
              type="text" 
              required 
              value={name}
              placeholder="e.g. Anand Sharma"
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors text-xs"
              onChange={(e) => setName(e.target.value)} 
            />
          </div>

          {/* Email Address */}
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px] flex items-center gap-1">
              <span>E-mail ID</span>
            </label>
            <input 
              type="email" 
              required 
              value={email}
              placeholder="e.g. anand@skyline.com"
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors text-xs"
              onChange={(e) => setEmail(e.target.value)} 
            />
          </div>

          {/* Role selection & Target */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px]">
                System Role
              </label>
              <select 
                value={role}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors text-xs" 
                onChange={(e) => setRole(e.target.value as UserRole)}
              >
                <option value="Executive">Executive</option>
                <option value="Manager">Manager</option>
                <option value="Admin">Admin</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 uppercase mb-1 tracking-wider text-[9px]">
                Target (Units)
              </label>
              <input 
                type="number" 
                required 
                value={kpiTarget}
                placeholder="e.g. 5"
                min="1"
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors text-xs font-mono"
                onChange={(e) => setKpiTarget(parseInt(e.target.value) || 0)} 
              />
            </div>
          </div>

          {/* Hire Button */}
          <div>
            <button 
              type="submit" 
              className="w-full px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl transition-all shadow-sm shadow-indigo-600/10 flex items-center justify-center gap-1.5 h-[36px]"
            >
              <Plus className="w-4 h-4" />
              Onboard Executive
            </button>
          </div>

        </form>
      </div>

    </div>
  );
}
