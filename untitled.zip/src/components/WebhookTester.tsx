import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { Send, Terminal, Code, CheckCircle, Smartphone, UserPlus, AlertCircle, Sparkles, Network, ArrowRight } from "lucide-react";

const PRESET_PAYLOADS = [
  {
    name: "Facebook Ad - Premium Lead",
    leadSource: "Facebook",
    customerName: "Siddharth Sen",
    mobileNumber: "+91 9123456780",
    city: "Mumbai",
    budget: 24000000,
    project: "Skyline Aurum Tower",
    unitType: "3 BHK Luxury",
  },
  {
    name: "99acres - Walk-in Enquiry",
    leadSource: "99acres",
    customerName: "Meenakshi Iyer",
    mobileNumber: "+91 9876543210",
    city: "Delhi",
    budget: 31000000,
    project: "Skyline Imperial Estates",
    unitType: "Penthouse",
  },
  {
    name: "Website - Mid-budget Unit",
    leadSource: "Website",
    customerName: "Rohit Deshmukh",
    mobileNumber: "+91 9911223344",
    city: "Pune",
    budget: 9500000,
    project: "Vanguard TechPark Woods",
    unitType: "2 BHK",
  },
  {
    name: "Google Search - Villa Buyer",
    leadSource: "Website",
    customerName: "Nisha Bangalore",
    mobileNumber: "+91 9440011223",
    city: "Bangalore",
    budget: 55000000,
    project: "Vanguard Sovereign Villas",
    unitType: "Villa",
  }
];

export default function WebhookTester() {
  const { activeTenantId } = useApp();
  const [selectedPreset, setSelectedPreset] = useState(0);
  const [customPayload, setCustomPayload] = useState(JSON.stringify(PRESET_PAYLOADS[0], null, 2));
  
  const [firing, setFiring] = useState(false);
  const [responseLog, setResponseLog] = useState<any>(null);
  const [logsTimeline, setLogsTimeline] = useState<string[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSelectPreset = (idx: number) => {
    setSelectedPreset(idx);
    const payloadWithTenant = {
      ...PRESET_PAYLOADS[idx],
      tenantId: activeTenantId,
      id: `lead_web_${Date.now()}`
    };
    setCustomPayload(JSON.stringify(payloadWithTenant, null, 2));
  };

  // Firing action calling real Express backend route
  const handleFireWebhook = async () => {
    setFiring(true);
    setResponseLog(null);
    setErrorMsg(null);
    setLogsTimeline(["📡 Establishing connection with API Lead Ingress Gateway..."]);

    let payloadObj: any;
    try {
      payloadObj = JSON.parse(customPayload);
      // Ensure tenant ID is set inside payload
      payloadObj.tenantId = activeTenantId;
      if (!payloadObj.id) {
        payloadObj.id = `lead_web_${Date.now()}`;
      }
    } catch (e: any) {
      setErrorMsg("Syntax Error: The payload must be formatted as valid JSON.");
      setFiring(false);
      return;
    }

    try {
      // Small timeout simulate sequence
      setTimeout(() => {
        setLogsTimeline(prev => [...prev, "🛠️ Omnichannel lead payload received by Node.js middleware."]);
      }, 400);

      setTimeout(() => {
        setLogsTimeline(prev => [...prev, "🧠 Querying Gemini-3.5-Flash to execute Instant AI Routing..."]);
      }, 900);

      const res = await fetch("/api/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payloadObj)
      });

      if (!res.ok) {
        throw new Error(`HTTP Webhook Gate Error (Status: ${res.status})`);
      }

      const data = await res.json();
      
      setTimeout(() => {
        setLogsTimeline(prev => [
          ...prev,
          `✅ Lead assigned to Agent ID: ${data.assignedExecutiveId}`,
          `💬 AI Generated WhatsApp text: "${data.welcomeMessage}"`,
          "💾 Synchronized records permanently in Firestore isolated tenant collections.",
          "🏁 Webhook process lifecycle successfully completed."
        ]);
        setResponseLog(data);
        setFiring(false);
      }, 1500);

    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Gateway Communication Failure.");
      setLogsTimeline(prev => [...prev, "❌ Failed: Process terminated due to a gateway exception."]);
      setFiring(false);
    }
  };

  return (
    <div className="space-y-6 font-sans" id="webhook-tester-view">
      
      {/* Introduction Banner */}
      <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-950 border border-slate-800 text-slate-100 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <span className="bg-indigo-500/20 text-indigo-300 font-mono text-[9px] uppercase font-bold px-2.5 py-1 rounded-full border border-indigo-500/30 flex items-center gap-1.5 w-fit">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            Omnichannel Ingress API
          </span>
          <h2 className="text-xl font-bold font-display text-white">Live Lead Ingestion Webhook Gateway</h2>
          <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
            Simulate real estate inquiry payloads arriving from Facebook Leads API, website forms, or portal webhooks. Track how the backend system parses, classifies, and automatically delegates leads using generative AI routing.
          </p>
        </div>
        <div className="text-xs text-slate-300 bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 shrink-0 font-mono flex items-center gap-2">
          <Network className="w-4 h-4 text-emerald-400" />
          <span>Endpoint:</span>
          <span className="bg-indigo-500/10 text-indigo-300 px-2 py-0.5 rounded border border-indigo-500/20">/api/webhook</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left column: JSON Payload Editor */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80 overflow-hidden flex flex-col h-[550px]">
          <div className="px-5 py-4 bg-slate-50 dark:bg-slate-950/50 border-b border-slate-100 dark:border-slate-800/60 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Code className="w-4 h-4 text-indigo-500" />
                Inquiry Payload JSON
              </span>
              <span className="bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-mono text-[9px] px-2 py-0.5 rounded border border-slate-200/40 dark:border-slate-700">
                POST Raw Body
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {PRESET_PAYLOADS.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectPreset(idx)}
                  className={`px-3 py-1 text-[10px] font-bold rounded-lg transition-all border ${
                    selectedPreset === idx
                      ? "bg-indigo-600 border-indigo-600 text-white shadow-xs shadow-indigo-600/10"
                      : "bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border-slate-200/50 dark:border-slate-700"
                  }`}
                >
                  {preset.leadSource} ({preset.city})
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 p-5 bg-slate-950 overflow-hidden relative group">
            <textarea
              value={customPayload}
              onChange={(e) => setCustomPayload(e.target.value)}
              className="w-full h-full bg-transparent text-emerald-400 font-mono text-xs border-none focus:ring-0 focus:outline-none resize-none leading-relaxed overflow-y-auto"
              id="webhook-payload-textarea"
            />
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-950/30 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
            <span className="text-[10px] text-slate-400 font-mono">
              Tenant Context: <span className="text-slate-600 dark:text-slate-300 font-semibold">{activeTenantId}</span>
            </span>
            <button
              onClick={handleFireWebhook}
              disabled={firing}
              className={`px-4.5 py-2 rounded-xl text-xs font-bold text-white shadow-sm flex items-center gap-2 transition-all ${
                firing
                  ? "bg-slate-400 dark:bg-slate-700 cursor-not-allowed opacity-60"
                  : "bg-indigo-600 hover:bg-indigo-500 shadow-indigo-500/10 hover:shadow-md"
              }`}
              id="webhook-fire-btn"
            >
              <Send className={`w-3.5 h-3.5 ${firing ? "animate-bounce" : ""}`} />
              {firing ? "Executing API Pipeline..." : "Fire Webhook Ingress"}
            </button>
          </div>
        </div>

        {/* Right column: Gateway Execution & Response Monitor */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80 overflow-hidden flex flex-col h-[550px]">
          <div className="px-5 py-4 bg-slate-50 dark:bg-slate-950/50 border-b border-slate-100 dark:border-slate-800/60 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Terminal className="w-4 h-4 text-indigo-500" />
              Real-time Ingress Monitor
            </span>
            {firing && (
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            )}
          </div>

          <div className="flex-1 p-5 space-y-4 overflow-y-auto">
            {/* Logs timeline */}
            {logsTimeline.length > 0 && (
              <div className="space-y-2 bg-slate-50 dark:bg-slate-950/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-850/80 font-mono text-xs text-slate-700 dark:text-slate-300">
                <div className="font-bold text-slate-900 dark:text-slate-200 text-[10px] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                  Live Execution Trace:
                </div>
                {logsTimeline.map((log, idx) => (
                  <div key={idx} className="flex items-start gap-2 leading-relaxed">
                    <span className="text-slate-400 select-none text-[10px]">{idx + 1}.</span>
                    <span>{log}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Error View */}
            {errorMsg && (
              <div className="p-4 bg-rose-50 dark:bg-rose-950/10 border border-rose-100 dark:border-rose-950/30 rounded-xl text-rose-700 dark:text-rose-400 text-xs flex gap-3">
                <AlertCircle className="w-5 h-5 flex-shrink-0 text-rose-500" />
                <div>
                  <div className="font-bold uppercase tracking-wider text-[10px]">Gateway Exception</div>
                  <div className="mt-1 font-mono text-[11px]">{errorMsg}</div>
                </div>
              </div>
            )}

            {/* Response JSON viewer */}
            {responseLog && (
              <div className="space-y-4">
                
                {/* Visual result boxes */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-4 bg-indigo-50/50 dark:bg-indigo-950/10 border border-indigo-100/60 dark:border-indigo-900/20 rounded-xl">
                    <div className="text-slate-400 text-[10px] uppercase font-bold mb-1 tracking-wider flex items-center gap-1.5">
                      <UserPlus className="w-3.5 h-3.5 text-indigo-500" />
                      Assigned Agent ID
                    </div>
                    <div className="font-bold text-slate-950 dark:text-slate-100 font-mono mt-1 text-sm">
                      {responseLog.assignedExecutiveId}
                    </div>
                  </div>
                  <div className="p-4 bg-emerald-50/50 dark:bg-emerald-950/10 border border-emerald-100/60 dark:border-emerald-900/20 rounded-xl">
                    <div className="text-slate-400 text-[10px] uppercase font-bold mb-1 tracking-wider flex items-center gap-1.5">
                      <Smartphone className="w-3.5 h-3.5 text-emerald-500" />
                      Engagement Engine
                    </div>
                    <div className="font-bold text-emerald-700 dark:text-emerald-400 text-xs mt-1 font-sans">
                      SMS Dispatched ✓
                    </div>
                  </div>
                </div>

                {/* WhatsApp preview mockup */}
                <div className="bg-emerald-50/20 dark:bg-emerald-950/10 rounded-xl border border-emerald-150/50 dark:border-emerald-900/20 p-4 text-xs text-slate-700 dark:text-slate-300 space-y-2 relative">
                  <div className="flex justify-between items-center border-b border-emerald-100/40 dark:border-emerald-900/20 pb-2">
                    <span className="font-bold text-emerald-800 dark:text-emerald-400 uppercase text-[9px] tracking-wider">SMS / WhatsApp Dispatch (Personalized by Gemini)</span>
                    <span className="text-[9px] bg-emerald-100 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-300 font-bold uppercase px-2 py-0.5 rounded-full">Mock Send Success</span>
                  </div>
                  <p className="italic text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-900/50 p-3 rounded-lg border border-emerald-100/30 dark:border-emerald-850/40 leading-relaxed font-sans mt-2">
                    "{responseLog.welcomeMessage}"
                  </p>
                </div>

                {/* Routing Reason */}
                <div className="bg-slate-50 dark:bg-slate-950/40 p-4 rounded-xl border border-slate-200/50 dark:border-slate-850 text-xs">
                  <div className="font-bold text-slate-700 dark:text-slate-300 uppercase text-[9px] tracking-wider mb-1.5 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                    AI Routing Reasoning
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed font-mono text-[11px]">
                    {responseLog.routingReason}
                  </p>
                </div>

                {/* Raw API Response code block */}
                <div className="space-y-1.5 font-mono text-xs">
                  <div className="font-bold text-slate-400 text-[10px] uppercase tracking-wider">Raw JSON Response:</div>
                  <pre className="p-3 bg-slate-950 text-emerald-400 rounded-xl overflow-x-auto max-h-[150px] border border-slate-800 text-[11px]">
                    {JSON.stringify(responseLog, null, 2)}
                  </pre>
                </div>
              </div>
            )}

            {!firing && !responseLog && !errorMsg && (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 p-6">
                <div className="bg-indigo-50 dark:bg-slate-800/40 p-4 rounded-2xl border border-indigo-100/50 dark:border-slate-850/50 mb-3">
                  <Code className="w-8 h-8 text-indigo-500" />
                </div>
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">Ingress Gateway Idle</p>
                <p className="text-xs max-w-xs mt-1 leading-relaxed text-slate-400">
                  Trigger an inbound webhook using the payload panel to observe AI Routing rules, CRM logs, and WhatsApp generation events in real time.
                </p>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
