import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { Save, Plus, Trash2, Key, HelpCircle, Lock } from "lucide-react";

export default function SettingsPanel() {
  const { activeTenant, simulatedUsers, currentUser, updateTenantSettings, addAgent } = useApp();
  
  const [companyName, setCompanyName] = useState("");
  const [subscriptionPlan, setSubscriptionPlan] = useState<any>("Standard");
  const [whatsappApiKey, setWhatsappApiKey] = useState("");
  const [whatsappPhoneId, setWhatsappPhoneId] = useState("");
  const [webhookUrl, setWebhookUrl] = useState("");
  const [routingRules, setRoutingRules] = useState<{ city: string; executiveId: string }[]>([]);
  
  const [newCity, setNewCity] = useState("");
  const [newExecutive, setNewExecutive] = useState("");
  
  const [saveStatus, setSaveStatus] = useState<string | null>(null);

  // Load state from activeTenant
  useEffect(() => {
    if (activeTenant) {
      setCompanyName(activeTenant.companyName || "");
      setSubscriptionPlan(activeTenant.subscriptionPlan || "Standard");
      setWhatsappApiKey(activeTenant.whatsappConfig?.apiKey || "");
      setWhatsappPhoneId(activeTenant.whatsappConfig?.phoneId || "");
      setWebhookUrl(activeTenant.webhookUrl || "");
      setRoutingRules(activeTenant.routingRules || []);
    }
  }, [activeTenant]);

  const executives = simulatedUsers.filter(u => u.role === "Executive");

  const handleAddRoutingRule = () => {
    if (!newCity || !newExecutive) return;
    setRoutingRules([...routingRules, { city: newCity, executiveId: newExecutive }]);
    setNewCity("");
    setNewExecutive("");
  };

  const handleRemoveRoutingRule = (index: number) => {
    const nextRules = [...routingRules];
    nextRules.splice(index, 1);
    setRoutingRules(nextRules);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (currentUser?.role !== "Admin") {
      alert("Role Permission Lock: Only Tenant Administrators are permitted to modify settings.");
      return;
    }

    try {
      await updateTenantSettings({
        companyName,
        subscriptionPlan,
        whatsappConfig: {
          apiKey: whatsappApiKey,
          phoneId: whatsappPhoneId
        },
        webhookUrl,
        routingRules
      });
      setSaveStatus("Success");
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (err: any) {
      console.error(err);
      alert("Error saving settings to cloud: " + err.message);
    }
  };

  // If user is not Admin, display high-end permission wall
  if (currentUser?.role !== "Admin") {
    return (
      <div className="bg-white rounded-xl shadow-md border border-slate-200 p-8 flex flex-col items-center justify-center text-center font-sans h-96">
        <div className="p-4 bg-rose-50 rounded-full text-rose-600 mb-4 border border-rose-100">
          <Lock className="w-8 h-8" />
        </div>
        <h3 className="text-lg font-bold text-slate-950 font-display">Administrative Credentials Required</h3>
        <p className="text-slate-500 max-w-sm text-sm mt-1">
          Your current role profile (<span className="font-semibold">{currentUser?.role}</span>) is restricted from editing the commercial White-Label platform and integration parameters.
        </p>
        <p className="text-xs text-indigo-600 font-medium mt-4">
          Please use the simulator panel at the top to toggle your identity to "SaaS Admin" to explore this module.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 font-sans" id="settings-panel-view">
      {/* Settings Form */}
      <form onSubmit={handleSave} className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
          <div>
            <h2 className="text-lg font-bold text-slate-900 font-display">White-Label Organization Settings</h2>
            <p className="text-xs text-slate-500">Manage API credentials, geographical lead distribution rules, and billing parameters.</p>
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-lg shadow-sm transition-all flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save Configuration
          </button>
        </div>

        <div className="p-6 space-y-6">
          {saveStatus === "Success" && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-xs font-semibold animate-pulse flex items-center gap-2">
              🟢 System parameters updated and synced to Firestore securely.
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* General Settings */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-indigo-950 tracking-wider uppercase border-b border-slate-100 pb-2">Business Settings</h3>
              
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Company Legal Name</label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">SaaS Subscription Tier</label>
                <select
                  value={subscriptionPlan}
                  onChange={(e) => setSubscriptionPlan(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors"
                >
                  <option value="Standard">Standard (Basic Routing)</option>
                  <option value="Enterprise">Enterprise (AI Core Routing)</option>
                  <option value="White-Label">White-Label CRM & Automation</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Webhook Ingress Endpoint</label>
                <input
                  type="text"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono bg-slate-100 text-slate-600 cursor-not-allowed"
                  disabled
                />
                <span className="text-[10px] text-slate-400 block mt-1">Simulated webhook receiver URL linked to Facebook Lead Ads & web inquiries.</span>
              </div>
            </div>

            {/* WhatsApp Integration API */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-indigo-950 tracking-wider uppercase border-b border-slate-100 pb-2">WhatsApp Business API Link</h3>
              
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">WABA Bearer API Key</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Key className="h-4 h-4 text-slate-400" />
                  </div>
                  <input
                    type="password"
                    value={whatsappApiKey}
                    onChange={(e) => setWhatsappApiKey(e.target.value)}
                    placeholder="Enter WhatsApp bearer access token"
                    className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">WhatsApp Phone ID</label>
                <input
                  type="text"
                  value={whatsappPhoneId}
                  onChange={(e) => setWhatsappPhoneId(e.target.value)}
                  placeholder="Enter business phone number ID"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors"
                />
              </div>

              <div className="bg-slate-50 border border-slate-100 p-3 rounded-lg text-xs text-slate-500 flex gap-2">
                <HelpCircle className="w-5 h-5 text-indigo-500 flex-shrink-0" />
                <span>
                  Dispatches real-time WhatsApp introductions instantly upon webhook receipt using your private API credentials. Saves template status logs locally.
                </span>
              </div>
            </div>
          </div>

            {/* Agent Management Module */}
            <div className="pt-6 border-t border-slate-100">
              <h3 className="text-sm font-bold text-indigo-950 tracking-wider uppercase border-b border-slate-100 pb-2 mb-4">Agent Management</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3 h-fit">
                  <h4 className="text-xs font-bold text-slate-700 uppercase">Hire New Agent</h4>
                  <input type="text" placeholder="Agent Name" className="w-full px-3 py-1.5 border border-slate-200 rounded-md text-xs bg-white" id="new-agent-name" />
                  <input type="email" placeholder="Agent Email" className="w-full px-3 py-1.5 border border-slate-200 rounded-md text-xs bg-white" id="new-agent-email" />
                  <button
                    type="button"
                    onClick={() => {
                      const name = (document.getElementById('new-agent-name') as HTMLInputElement).value;
                      const email = (document.getElementById('new-agent-email') as HTMLInputElement).value;
                      if (!name || !email) return;
                      addAgent({ name, email, role: "Executive" });
                      (document.getElementById('new-agent-name') as HTMLInputElement).value = "";
                      (document.getElementById('new-agent-email') as HTMLInputElement).value = "";
                    }}
                    className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-md"
                  >
                    Hire Agent
                  </button>
                </div>
                <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
                  <table className="w-full text-left text-xs text-slate-600">
                    <thead className="bg-slate-50 text-slate-700 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="px-4 py-2">Name</th>
                        <th className="px-4 py-2">Email</th>
                      </tr>
                    </thead>
                    <tbody>
                      {simulatedUsers.map(u => (
                        <tr key={u.userId} className="border-b border-slate-100">
                          <td className="px-4 py-2">{u.name}</td>
                          <td className="px-4 py-2">{u.email}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

        </div>
      </form>
    </div>
  );
}
