import React from "react";
import { useApp } from "../context/AppContext";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from "recharts";
import { Users, Landmark, CheckSquare, TrendingUp, Sparkles, Target, BarChart3, Activity } from "lucide-react";

export default function KpiDashboard() {
  const { leads, bookings, payments } = useApp();

  const totalLeads = leads.length;
  const totalBookings = bookings.length;
  const totalRevenue = payments.reduce((sum, p) => sum + p.amount, 0);
  const conversionRate = totalLeads > 0 ? ((totalBookings / totalLeads) * 100).toFixed(1) : "0.0";

  const leadsBySource = leads.reduce((acc: any, lead) => {
    acc[lead.leadSource] = (acc[lead.leadSource] || 0) + 1;
    return acc;
  }, {});

  const pieData = Object.entries(leadsBySource).map(([name, value]) => ({ name, value }));

  const monthlyRevenue = payments.reduce((acc: any, p) => {
    const month = new Date(p.paymentDate).toLocaleString('default', { month: 'short' });
    acc[month] = (acc[month] || 0) + p.amount;
    return acc;
  }, {});

  const barData = Object.entries(monthlyRevenue).map(([name, value]) => ({ name, value }));

  const COLORS = ["#6366f1", "#10b981", "#f59e0b", "#ec4899"];

  return (
    <div className="space-y-6 font-sans">
      
      {/* Dynamic Header */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 rounded-2xl p-6 text-white border border-slate-800/80 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 w-fit">
            <Sparkles className="w-3 h-3 text-indigo-400" />
            Executive Workspace Metrics
          </span>
          <h2 className="text-xl font-bold font-display mt-2">Revenue Operations Center</h2>
          <p className="text-xs text-slate-400 mt-1">Real-time analysis of lead acquisition source performance and closed deal volume.</p>
        </div>
        <div className="bg-slate-800/40 border border-slate-700/30 rounded-xl px-4 py-2.5 flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          <div className="text-xs">
            <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Operational Mode</div>
            <div className="text-slate-200 font-semibold font-mono mt-0.5">Continuous Monitoring</div>
          </div>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { title: "Total Acquired Leads", value: totalLeads, desc: "Across active campaign routes", icon: Users, color: "text-indigo-600 dark:text-indigo-400", bg: "bg-indigo-50/40 dark:bg-indigo-950/20 border-indigo-100 dark:border-indigo-900/30" },
          { title: "Fully Booked Deals", value: totalBookings, desc: "Contracted sales finalized", icon: CheckSquare, color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-100 dark:border-emerald-900/30" },
          { title: "Capital Cleared", value: `INR ${totalRevenue.toLocaleString()}`, desc: "Recognized payments received", icon: Landmark, color: "text-pink-600 dark:text-pink-400", bg: "bg-pink-50/40 dark:bg-pink-950/20 border-pink-100 dark:border-pink-900/30" },
          { title: "Lead-to-Deal Rate", value: `${conversionRate}%`, desc: "Inquiry to sales conversion", icon: TrendingUp, color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-50/40 dark:bg-amber-950/20 border-amber-100 dark:border-amber-900/30" },
        ].map((item, i) => (
          <div key={i} className={`bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80 hover:shadow-md transition-all duration-200 flex flex-col justify-between relative overflow-hidden group`}>
            <div className="flex justify-between items-start">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{item.title}</p>
                <p className="text-2xl font-black text-slate-950 dark:text-white mt-1.5 font-display tracking-tight">{item.value}</p>
              </div>
              <div className={`p-2.5 rounded-xl ${item.bg} flex items-center justify-center border group-hover:scale-105 transition-transform`}>
                <item.icon className={`w-5 h-5 ${item.color}`} />
              </div>
            </div>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-4 border-t border-slate-100 dark:border-slate-800/80 pt-2 font-mono flex items-center gap-1">
              <span>●</span> {item.desc}
            </p>
          </div>
        ))}
      </div>

      {/* Visual Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Leads by Source */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80 flex flex-col">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-indigo-500" />
              <h3 className="text-sm font-bold text-slate-950 dark:text-white font-display">Acquisition Channel Efficacy</h3>
            </div>
            <span className="text-[9px] font-mono text-slate-400 uppercase">Interactive Pie</span>
          </div>
          {pieData.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center text-slate-400 italic">
              No leads available to chart acquisition channels.
            </div>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie 
                    data={pieData} 
                    dataKey="value" 
                    nameKey="name" 
                    cx="50%" 
                    cy="50%" 
                    innerRadius={60}
                    outerRadius={80} 
                    paddingAngle={4}
                    label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      borderRadius: "12px", 
                      background: "#0f172a", 
                      border: "none", 
                      color: "#fff",
                      fontSize: "11px",
                      fontFamily: "monospace"
                    }} 
                  />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: "11px" }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Revenue Trend */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800/80 flex flex-col">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-500" />
              <h3 className="text-sm font-bold text-slate-950 dark:text-white font-display">Capital Realization Velocity</h3>
            </div>
            <span className="text-[9px] font-mono text-slate-400 uppercase">Monthly Aggregate</span>
          </div>
          {barData.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center text-slate-400 italic">
              No installment payments processed yet.
            </div>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData}>
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <Tooltip 
                    cursor={{ fill: '#f1f5f9', opacity: 0.1 }}
                    contentStyle={{ 
                      borderRadius: "12px", 
                      background: "#0f172a", 
                      border: "none", 
                      color: "#fff",
                      fontSize: "11px",
                      fontFamily: "monospace"
                    }}
                    formatter={(value: any) => [`INR ${value.toLocaleString()}`, "Cleared Capital"]}
                  />
                  <Bar dataKey="value" fill="url(#barGradient)" radius={[6, 6, 0, 0]}>
                    {barData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill="#4f46e5" />
                    ))}
                  </Bar>
                  <defs>
                    <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#6366f1" />
                      <stop offset="100%" stopColor="#4f46e5" />
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
