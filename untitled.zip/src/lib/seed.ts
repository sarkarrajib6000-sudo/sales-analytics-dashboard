import { db } from "./firebase";
import { collection, doc, writeBatch, getDocs, query, limit } from "firebase/firestore";
import { Tenant, User, Lead, Booking, Payment, AutomationLog } from "../types";

export const MOCK_TENANTS: Tenant[] = [
  {
    tenantId: "skyline-realty",
    companyName: "Skyline Realty & Co.",
    ownerEmail: "rksarkar6000@gmail.com", // Admin email
    subscriptionPlan: "Enterprise",
    whatsappConfig: {
      apiKey: "waba_live_key_993a8c71b12d90ef",
      phoneId: "phone_id_1029301920391"
    },
    webhookUrl: "https://api.propflow.io/v1/webhooks/skyline",
    routingRules: [
      { city: "Mumbai", executiveId: "skyline-exec-amit" },
      { city: "Delhi", executiveId: "skyline-exec-neha" }
    ]
  },
  {
    tenantId: "vanguard-devs",
    companyName: "Vanguard Developers Ltd",
    ownerEmail: "ananya@vanguard.com",
    subscriptionPlan: "White-Label",
    whatsappConfig: {
      apiKey: "waba_live_key_552f8d81e92c22cf",
      phoneId: "phone_id_440192039402"
    },
    webhookUrl: "https://api.propflow.io/v1/webhooks/vanguard",
    routingRules: [
      { city: "Pune", executiveId: "vanguard-exec-rohan" },
      { city: "Bangalore", executiveId: "vanguard-exec-sneha" }
    ]
  }
];

export const MOCK_USERS: User[] = [
  // Skyline Realty Staff
  {
    userId: "skyline-admin-1",
    tenantId: "skyline-realty",
    name: "Rajesh Kumar (SaaS Admin)",
    email: "rksarkar6000@gmail.com",
    role: "Admin"
  },
  {
    userId: "skyline-manager-1",
    tenantId: "skyline-realty",
    name: "Priya Sharma (Manager)",
    email: "priya@skylinerealty.com",
    role: "Manager"
  },
  {
    userId: "skyline-exec-amit",
    tenantId: "skyline-realty",
    name: "Amit Patel (Senior Executive)",
    email: "amit@skylinerealty.com",
    role: "Executive"
  },
  {
    userId: "skyline-exec-neha",
    tenantId: "skyline-realty",
    name: "Neha Sen (Sales Executive)",
    email: "neha@skylinerealty.com",
    role: "Executive"
  },

  // Vanguard Developers Staff
  {
    userId: "vanguard-admin-1",
    tenantId: "vanguard-devs",
    name: "Vikram Singh (Director)",
    email: "vikram@vanguard.com",
    role: "Admin"
  },
  {
    userId: "vanguard-manager-1",
    tenantId: "vanguard-devs",
    name: "Ananya Roy (Manager)",
    email: "ananya@vanguard.com",
    role: "Manager"
  },
  {
    userId: "vanguard-exec-rohan",
    tenantId: "vanguard-devs",
    name: "Rohan Gupta (Lead Executive)",
    email: "rohan@vanguard.com",
    role: "Executive"
  },
  {
    userId: "vanguard-exec-sneha",
    tenantId: "vanguard-devs",
    name: "Sneha Rao (Associate Exec)",
    email: "sneha@vanguard.com",
    role: "Executive"
  }
];

// Build relative dates based on current time
const now = new Date();
const getOffsetDateString = (daysOffset: number) => {
  const d = new Date();
  d.setDate(now.getDate() + daysOffset);
  return d.toISOString();
};

export const MOCK_LEADS: Lead[] = [
  // Skyline Realty Leads
  {
    id: "lead-skyline-1",
    tenantId: "skyline-realty",
    leadDate: getOffsetDateString(-5),
    customerName: "Sandeep Malhotra",
    mobileNumber: "+91 9812234501",
    city: "Mumbai",
    budget: 18500000,
    project: "Skyline Aurum Tower",
    unitType: "3 BHK Luxury",
    leadSource: "Facebook",
    assignedExecutiveId: "skyline-exec-amit",
    leadStatus: "Site Visit Scheduled",
    nextFollowUpDate: getOffsetDateString(2), // 2 days in future -> 🟢 On Track
    automationStatus: "On Track",
    notes: "Customer scheduled a site visit for Saturday. Highly interested in premium lower deck units."
  },
  {
    id: "lead-skyline-2",
    tenantId: "skyline-realty",
    leadDate: getOffsetDateString(-10),
    customerName: "Karan Johar",
    mobileNumber: "+91 9923485710",
    city: "Mumbai",
    budget: 12000000,
    project: "Skyline Green Meadows",
    unitType: "2 BHK",
    leadSource: "99acres",
    assignedExecutiveId: "skyline-exec-neha",
    leadStatus: "Follow-up",
    nextFollowUpDate: getOffsetDateString(-1), // Past due by 1 day -> 🟡 Follow-up Due
    automationStatus: "Follow-up Due",
    notes: "Called but client was driving. Requested callback today."
  },
  {
    id: "lead-skyline-3",
    tenantId: "skyline-realty",
    leadDate: getOffsetDateString(-15),
    customerName: "Aishwarya Rai",
    mobileNumber: "+91 9831122334",
    city: "Delhi",
    budget: 35000000,
    project: "Skyline Imperial Estates",
    unitType: "Penthouse",
    leadSource: "Website",
    assignedExecutiveId: "skyline-exec-neha",
    leadStatus: "Negotiation",
    nextFollowUpDate: getOffsetDateString(-4), // Past due by 4 days -> 🔴 CRITICAL OVERDUE
    automationStatus: "Escalated",
    notes: "Price negotiations stalled over developer discount percentage. Needs manager intervention."
  },
  {
    id: "lead-skyline-4",
    tenantId: "skyline-realty",
    leadDate: getOffsetDateString(-2),
    customerName: "Rohan Mehra",
    mobileNumber: "+91 9110022334",
    city: "Mumbai",
    budget: 8500000,
    project: "Skyline Crest",
    unitType: "1 BHK Studio",
    leadSource: "Walk-in",
    assignedExecutiveId: "skyline-exec-amit",
    leadStatus: "Booked",
    nextFollowUpDate: getOffsetDateString(30),
    automationStatus: "On Track",
    notes: "Booking confirmed! Unit 1402 allotted. Verification in progress."
  },

  // Vanguard Developers Leads
  {
    id: "lead-vanguard-1",
    tenantId: "vanguard-devs",
    leadDate: getOffsetDateString(-4),
    customerName: "Aditya Chopra",
    mobileNumber: "+91 9771122001",
    city: "Pune",
    budget: 14500000,
    project: "Vanguard TechPark Woods",
    unitType: "3 BHK",
    leadSource: "Website",
    assignedExecutiveId: "vanguard-exec-rohan",
    leadStatus: "Connected",
    nextFollowUpDate: getOffsetDateString(1), // Tomorrow -> 🟢 On Track
    automationStatus: "On Track",
    notes: "First call completed. Client is buying for investment purposes near IT corridor."
  },
  {
    id: "lead-vanguard-2",
    tenantId: "vanguard-devs",
    leadDate: getOffsetDateString(-12),
    customerName: "Meera Nair",
    mobileNumber: "+91 9882233445",
    city: "Bangalore",
    budget: 22000000,
    project: "Vanguard Heights",
    unitType: "2.5 BHK",
    leadSource: "Walk-in",
    assignedExecutiveId: "vanguard-exec-sneha",
    leadStatus: "Site Visit Completed",
    nextFollowUpDate: getOffsetDateString(-2), // 2 days past due -> 🟡 Follow-up Due
    automationStatus: "Follow-up Due",
    notes: "Completed site visit last Sunday. Requested revised commercial quote with payment plan details."
  },
  {
    id: "lead-vanguard-3",
    tenantId: "vanguard-devs",
    leadDate: getOffsetDateString(-20),
    customerName: "Sanjay Dutt",
    mobileNumber: "+91 9553344556",
    city: "Bangalore",
    budget: 45000000,
    project: "Vanguard Sovereign Villas",
    unitType: "Villa",
    leadSource: "99acres",
    assignedExecutiveId: "vanguard-exec-sneha",
    leadStatus: "Follow-up",
    nextFollowUpDate: getOffsetDateString(-5), // 5 days past due -> 🔴 CRITICAL OVERDUE
    automationStatus: "Escalated",
    notes: "Lead is completely cold. Unresponsive to multiple calls. Manager escalation required to re-route."
  }
];

export const MOCK_BOOKINGS: Booking[] = [
  // Skyline Realty Bookings
  {
    bookingId: "booking-skyline-1",
    tenantId: "skyline-realty",
    leadId: "lead-skyline-4",
    propertyName: "Skyline Crest",
    unitNumber: "1402",
    dealValue: 8500000,
    amountReceived: 2500000,
    balanceDue: 6000000,
    paymentStatus: "Partially Paid",
    nextDueDate: getOffsetDateString(15), // future -> on track
    createdAt: getOffsetDateString(-2)
  },
  {
    bookingId: "booking-skyline-2",
    tenantId: "skyline-realty",
    leadId: "lead-skyline-1",
    propertyName: "Skyline Aurum Tower",
    unitNumber: "2201-A",
    dealValue: 18500000,
    amountReceived: 18500000,
    balanceDue: 0,
    paymentStatus: "Fully Paid",
    nextDueDate: getOffsetDateString(180),
    createdAt: getOffsetDateString(-5)
  },

  // Vanguard Developers Bookings
  {
    bookingId: "booking-vanguard-1",
    tenantId: "vanguard-devs",
    leadId: "lead-vanguard-1",
    propertyName: "Vanguard TechPark Woods",
    unitNumber: "C-904",
    dealValue: 14500000,
    amountReceived: 1500000,
    balanceDue: 13000000,
    paymentStatus: "Balance Overdue",
    nextDueDate: getOffsetDateString(-5), // Overdue past date
    createdAt: getOffsetDateString(-15)
  }
];

export const MOCK_PAYMENTS: Payment[] = [
  // Skyline Payments
  {
    paymentId: "pay-skyline-1",
    tenantId: "skyline-realty",
    bookingId: "booking-skyline-1",
    amount: 1000000,
    paymentDate: getOffsetDateString(-2),
    paymentMethod: "Wire Transfer",
    status: "Cleared"
  },
  {
    paymentId: "pay-skyline-2",
    tenantId: "skyline-realty",
    bookingId: "booking-skyline-1",
    amount: 1500000,
    paymentDate: getOffsetDateString(-1),
    paymentMethod: "Cheque",
    status: "Cleared"
  },
  {
    paymentId: "pay-skyline-3",
    tenantId: "skyline-realty",
    bookingId: "booking-skyline-2",
    amount: 18500000,
    paymentDate: getOffsetDateString(-5),
    paymentMethod: "Wire Transfer",
    status: "Cleared"
  },

  // Vanguard Payments
  {
    paymentId: "pay-vanguard-1",
    tenantId: "vanguard-devs",
    bookingId: "booking-vanguard-1",
    amount: 1500000,
    paymentDate: getOffsetDateString(-15),
    paymentMethod: "Wire Transfer",
    status: "Cleared"
  }
];

export const MOCK_LOGS: AutomationLog[] = [
  {
    logId: "log-skyline-1",
    tenantId: "skyline-realty",
    leadId: "lead-skyline-1",
    eventType: "Lead Ingested",
    executionTimestamp: getOffsetDateString(-5),
    status: "Success",
    details: "Omichannel lead successfully ingested from Facebook Lead Ad: Sandeep Malhotra."
  },
  {
    logId: "log-skyline-2",
    tenantId: "skyline-realty",
    leadId: "lead-skyline-1",
    eventType: "AI Routing",
    executionTimestamp: getOffsetDateString(-5),
    status: "Success",
    details: "Assigned Sandeep Malhotra to Amit Patel. City 'Mumbai' matched executive availability rules."
  },
  {
    logId: "log-skyline-3",
    tenantId: "skyline-realty",
    leadId: "lead-skyline-1",
    eventType: "Welcome Text Dispatched",
    executionTimestamp: getOffsetDateString(-5),
    status: "Success",
    details: "Sent WhatsApp message: 'Welcome Sandeep Malhotra to Skyline Realty! An agent will call you soon.'"
  },
  {
    logId: "log-vanguard-1",
    tenantId: "vanguard-devs",
    leadId: "lead-vanguard-3",
    eventType: "SLA Escalation",
    executionTimestamp: getOffsetDateString(-1),
    status: "Success",
    details: "Lead follow-up date exceeded SLA limit of 3 days. System escalated state to 'Escalated'."
  }
];

export async function seedMockData() {
  try {
    const tenantsSnap = await getDocs(query(collection(db, "tenants"), limit(1)));
    if (!tenantsSnap.empty) {
      console.log("Database already contains data, skipping auto-seed.");
      return;
    }

    console.log("Seeding initial multi-tenant real estate data...");

    // Batch seed Tenants
    const batch = writeBatch(db);

    MOCK_TENANTS.forEach((tenant) => {
      const ref = doc(db, "tenants", tenant.tenantId);
      batch.set(ref, tenant);
    });

    MOCK_USERS.forEach((user) => {
      const ref = doc(db, "users", user.userId);
      batch.set(ref, user);
    });

    MOCK_LEADS.forEach((lead) => {
      const ref = doc(db, "leads", lead.id);
      batch.set(ref, lead);
    });

    MOCK_BOOKINGS.forEach((booking) => {
      const ref = doc(db, "bookings", booking.bookingId);
      batch.set(ref, booking);
    });

    MOCK_PAYMENTS.forEach((payment) => {
      const ref = doc(db, "payments", payment.paymentId);
      batch.set(ref, payment);
    });

    MOCK_LOGS.forEach((log) => {
      const ref = doc(db, "automation_logs", log.logId);
      batch.set(ref, log);
    });

    await batch.commit();
    console.log("Database seeded successfully.");
  } catch (error) {
    console.error("Failed to seed database:", error);
  }
}
