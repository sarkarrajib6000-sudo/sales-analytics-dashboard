import React, { createContext, useContext, useState, useEffect } from "react";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";
import { Tenant, User, Lead, Booking, Payment, AutomationLog, UserRole } from "../types";
import { collection, query, where, onSnapshot, doc, updateDoc, setDoc, deleteDoc, addDoc, getDoc } from "firebase/firestore";
import { MOCK_TENANTS, MOCK_USERS, seedMockData } from "../lib/seed";

interface AppContextType {
  // Tenant & Role Simulation settings
  activeTenantId: string;
  setActiveTenantId: (id: string) => void;
  activeTenant: Tenant | null;
  
  simulatedUsers: User[];
  currentUserId: string;
  setCurrentUserId: (id: string) => void;
  currentUser: User | null;

  // Real-time Collections for Active Tenant
  leads: Lead[];
  bookings: Booking[];
  payments: Payment[];
  logs: AutomationLog[];
  loading: boolean;
  error: string | null;

  // Real-time Actions
  updateLeadStatus: (leadId: string, status: Lead["leadStatus"], notes?: string) => Promise<void>;
  updateLeadFollowUp: (leadId: string, nextDate: string, notes?: string) => Promise<void>;
  deleteLead: (leadId: string) => Promise<void>;
  addLead: (lead: Omit<Lead, "id" | "tenantId" | "automationStatus">) => Promise<void>;
  addBooking: (booking: Omit<Booking, "bookingId" | "tenantId">) => Promise<void>;
  addPayment: (payment: Omit<Payment, "paymentId" | "tenantId">) => Promise<void>;
  updateTenantSettings: (updatedTenant: Partial<Tenant>) => Promise<void>;
  addAgent: (agent: Omit<User, "userId" | "tenantId">) => void;
  triggerResetDb: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [activeTenantId, setActiveTenantId] = useState<string>("skyline-realty");
  const [currentUserId, setCurrentUserId] = useState<string>("skyline-admin-1");
  const [activeTenant, setActiveTenant] = useState<Tenant | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [localAgents, setLocalAgents] = useState<User[]>([]);

  const [leads, setLeads] = useState<Lead[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [logs, setLogs] = useState<AutomationLog[]>([]);

  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // 1. Run seed check on boot
  useEffect(() => {
    async function boot() {
      try {
        await seedMockData();
        setLoading(false);
      } catch (err) {
        console.error("Boot seeding error:", err);
        setLoading(false);
      }
    }
    boot();
  }, []);

  // 2. Sync Active Tenant configuration and user list
  useEffect(() => {
    // Find matching tenant config in local static list as fallback/initial
    const localTenant = MOCK_TENANTS.find(t => t.tenantId === activeTenantId);
    if (localTenant) {
      setActiveTenant(localTenant);
    }

    // Subscribe to tenant settings dynamically from Firestore
    const tenantDocRef = doc(db, "tenants", activeTenantId);
    const unsubTenant = onSnapshot(tenantDocRef, (snap) => {
      if (snap.exists()) {
        setActiveTenant(snap.data() as Tenant);
      }
    }, (err) => {
      console.error("Error reading tenant:", err);
    });

    // Sub-list of simulated users belonging to active tenant
    const tUsers = MOCK_USERS.filter(u => u.tenantId === activeTenantId);
    // Find the current active simulated user
    let user = tUsers.find(u => u.userId === currentUserId);
    if (!user && tUsers.length > 0) {
      user = tUsers[0];
      setCurrentUserId(tUsers[0].userId);
    }
    setCurrentUser(user || null);

    return () => {
      unsubTenant();
    };
  }, [activeTenantId, currentUserId]);

  // 3. Setup onSnapshot listeners for isolated collections
  useEffect(() => {
    if (!activeTenantId) return;

    setLoading(true);

    // Filter Leads by active tenantId
    const leadsQuery = query(collection(db, "leads"), where("tenantId", "==", activeTenantId));
    const unsubLeads = onSnapshot(leadsQuery, (snapshot) => {
      const list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as Omit<Lead, "id"> }));
      
      // Dynamic SLA calculations (SLA Timer Event)
      const calculatedList = list.map(lead => {
        const nextDate = new Date(lead.nextFollowUpDate);
        const currTime = new Date();
        const diffMs = nextDate.getTime() - currTime.getTime();
        const diffDays = diffMs / (1000 * 60 * 60 * 24);

        let autoStatus: Lead["automationStatus"] = "On Track";
        
        if (lead.leadStatus === "Booked" || lead.leadStatus === "Lost") {
          autoStatus = "On Track";
        } else if (diffDays < -3) {
          autoStatus = "Escalated"; // Escalated pulls it into "Manager Alerts Panel"
        } else if (diffDays < 0) {
          autoStatus = "Follow-up Due";
        } else {
          autoStatus = "On Track";
        }

        // Auto-update Firestore status if it mismatch to ensure persistent integrity
        if (lead.automationStatus !== autoStatus) {
          const leadDocRef = doc(db, "leads", lead.id);
          updateDoc(leadDocRef, { automationStatus: autoStatus }).catch(e => {
            console.error("Auto SLA update failed:", e);
          });
        }

        return {
          ...lead,
          automationStatus: autoStatus
        };
      });

      // Sort by date descending
      calculatedList.sort((a, b) => new Date(b.leadDate).getTime() - new Date(a.leadDate).getTime());
      setLeads(calculatedList);
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, `leads [tenantId: ${activeTenantId}]`);
    });

    // Bookings
    const bookingsQuery = query(collection(db, "bookings"), where("tenantId", "==", activeTenantId));
    const unsubBookings = onSnapshot(bookingsQuery, (snapshot) => {
      const list = snapshot.docs.map(doc => {
        const data = doc.data() as Booking;
        
        // Automation Event 4 (Financial Controls): Auto-calculate overdue invoices
        const currTime = new Date();
        const dueTime = new Date(data.nextDueDate);
        let paymentState = data.paymentStatus;
        if (data.balanceDue > 0 && currTime > dueTime && data.paymentStatus !== "Balance Overdue") {
          paymentState = "Balance Overdue";
          // Sync with Firestore
          updateDoc(doc.ref, { paymentStatus: "Balance Overdue" }).catch(e => console.error(e));
        }

        return {
          ...data,
          paymentStatus: paymentState
        };
      });
      setBookings(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, `bookings [tenantId: ${activeTenantId}]`);
    });

    // Payments
    const paymentsQuery = query(collection(db, "payments"), where("tenantId", "==", activeTenantId));
    const unsubPayments = onSnapshot(paymentsQuery, (snapshot) => {
      const list = snapshot.docs.map(doc => doc.data() as Payment);
      setPayments(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, `payments [tenantId: ${activeTenantId}]`);
    });

    // Automation Logs
    const logsQuery = query(collection(db, "automation_logs"), where("tenantId", "==", activeTenantId));
    const unsubLogs = onSnapshot(logsQuery, (snapshot) => {
      const list = snapshot.docs.map(doc => doc.data() as AutomationLog);
      list.sort((a, b) => new Date(b.executionTimestamp).getTime() - new Date(a.executionTimestamp).getTime());
      setLogs(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, `automation_logs [tenantId: ${activeTenantId}]`);
    });

    return () => {
      unsubLeads();
      unsubBookings();
      unsubPayments();
      unsubLogs();
    };
  }, [activeTenantId]);

  // 4. Mutation Helpers with full Zero-Trust checks and logging
  const updateLeadStatus = async (leadId: string, status: Lead["leadStatus"], notes?: string) => {
    const path = `leads/${leadId}`;
    try {
      const leadRef = doc(db, "leads", leadId);
      const updatePayload: Partial<Lead> = { leadStatus: status };
      if (notes) {
        updatePayload.notes = notes;
      }
      
      // If status is Booked or Lost, clean up escalation alerts
      if (status === "Booked" || status === "Lost") {
        updatePayload.automationStatus = "On Track";
      }

      await updateDoc(leadRef, updatePayload);

      // Track follow-up status update log
      await addDoc(collection(db, "automation_logs"), {
        logId: `log_upd_${Date.now()}`,
        tenantId: activeTenantId,
        leadId,
        eventType: "Followup Updated",
        executionTimestamp: new Date().toISOString(),
        status: "Success",
        details: `Lead status updated to [${status}]. Notes: ${notes || "No notes appended"}`
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  const updateLeadFollowUp = async (leadId: string, nextDate: string, notes?: string) => {
    const path = `leads/${leadId}`;
    try {
      const leadRef = doc(db, "leads", leadId);
      const updatePayload: Partial<Lead> = {
        nextFollowUpDate: nextDate,
        automationStatus: "On Track" // reset to On Track
      };
      if (notes) {
        updatePayload.notes = notes;
      }
      await updateDoc(leadRef, updatePayload);

      await addDoc(collection(db, "automation_logs"), {
        logId: `log_upd_${Date.now()}`,
        tenantId: activeTenantId,
        leadId,
        eventType: "Followup Updated",
        executionTimestamp: new Date().toISOString(),
        status: "Success",
        details: `Logged follow-up action. Rescheduled follow-up to ${new Date(nextDate).toLocaleDateString()}. Notes: ${notes || "Completed contact task."}`
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  const deleteLead = async (leadId: string) => {
    const path = `leads/${leadId}`;
    try {
      await deleteDoc(doc(db, "leads", leadId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  };

  const addLead = async (lead: Omit<Lead, "id" | "tenantId" | "automationStatus">) => {
    const leadId = `lead_${Date.now()}`;
    const path = `leads/${leadId}`;
    try {
      const newLead: Lead = {
        ...lead,
        id: leadId,
        tenantId: activeTenantId,
        automationStatus: "On Track"
      };
      await setDoc(doc(db, "leads", leadId), newLead);
      
      await addDoc(collection(db, "automation_logs"), {
        logId: `log_c_${Date.now()}`,
        tenantId: activeTenantId,
        leadId,
        eventType: "Lead Ingested",
        executionTimestamp: new Date().toISOString(),
        status: "Success",
        details: `New lead created: ${lead.customerName}`
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  const addBooking = async (booking: Omit<Booking, "bookingId" | "tenantId">) => {
    const bookingId = `book_${Date.now()}`;
    const path = `bookings/${bookingId}`;
    try {
      const newBooking: Booking = {
        ...booking,
        bookingId,
        tenantId: activeTenantId,
        createdAt: new Date().toISOString()
      };
      await setDoc(doc(db, "bookings", bookingId), newBooking);

      // Log success
      await addDoc(collection(db, "automation_logs"), {
        logId: `log_b_${Date.now()}`,
        tenantId: activeTenantId,
        leadId: booking.leadId,
        eventType: "Welcome Text Dispatched",
        executionTimestamp: new Date().toISOString(),
        status: "Success",
        details: `Booking confirmed for unit ${booking.unitNumber} at ${booking.propertyName}. Contract deal value: INR ${booking.dealValue.toLocaleString()}`
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  const addPayment = async (payment: Omit<Payment, "paymentId" | "tenantId">) => {
    const paymentId = `pay_${Date.now()}`;
    const path = `payments/${paymentId}`;
    try {
      const newPayment: Payment = {
        ...payment,
        paymentId,
        tenantId: activeTenantId
      };
      await setDoc(doc(db, "payments", paymentId), newPayment);

      // Adjust the booking amountReceived and balanceDue
      const bookingRef = doc(db, "bookings", payment.bookingId);
      const bookingDoc = await getDoc(bookingRef);
      if (bookingDoc.exists()) {
        const bData = bookingDoc.data() as Booking;
        const newAmtReceived = bData.amountReceived + payment.amount;
        const newBalance = Math.max(0, bData.dealValue - newAmtReceived);
        let pStatus: Booking["paymentStatus"] = "Partially Paid";
        if (newBalance === 0) {
          pStatus = "Fully Paid";
        } else if (new Date() > new Date(bData.nextDueDate)) {
          pStatus = "Balance Overdue";
        }

        await updateDoc(bookingRef, {
          amountReceived: newAmtReceived,
          balanceDue: newBalance,
          paymentStatus: pStatus
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  const updateTenantSettings = async (updatedTenant: Partial<Tenant>) => {
    const path = `tenants/${activeTenantId}`;
    try {
      const tenantRef = doc(db, "tenants", activeTenantId);
      await updateDoc(tenantRef, updatedTenant);
      
      // Update local state state as well
      setActiveTenant(prev => prev ? { ...prev, ...updatedTenant } : null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  const addAgent = (agent: Omit<User, "userId" | "tenantId">) => {
    setLocalAgents([...localAgents, { ...agent, userId: `agent_${Date.now()}`, tenantId: activeTenantId }]);
  };

  const triggerResetDb = async () => {
    // For local simulation speed, let's delete collections and re-seed
    setLoading(true);
    try {
      // Direct reset bypass: just delete all simulated local and seed again
      // The easiest way is clear state and push mock data batch
      await seedMockData();
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const simulatedUsers = [...MOCK_USERS.filter(u => u.tenantId === activeTenantId), ...localAgents.filter(u => u.tenantId === activeTenantId)];

  return (
    <AppContext.Provider
      value={{
        activeTenantId,
        setActiveTenantId,
        activeTenant,
        simulatedUsers,
        currentUserId,
        setCurrentUserId,
        currentUser,
        leads,
        bookings,
        payments,
        logs,
        loading,
        error,
        updateLeadStatus,
        updateLeadFollowUp,
        deleteLead,
        addLead,
        addBooking,
        addPayment,
        updateTenantSettings,
        addAgent,
        triggerResetDb
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
