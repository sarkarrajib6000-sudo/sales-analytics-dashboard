import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, doc, setDoc, getDoc, getDocs, updateDoc, serverTimestamp } from "firebase/firestore";
import fs from "fs";

// Load Firebase configuration
const firebaseConfigPath = path.join(process.cwd(), "firebase-applet-config.json");
const firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, "utf8"));

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization of Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
  }
  return aiClient;
}

// 1. Webhook Lead Ingress & AI Routing Endpoint
app.post("/api/webhook", async (req, res) => {
  const payload = req.body;
  
  // Extract tenant ID, fallback to 'demo-tenant-propflow' for testing/simulation
  const tenantId = payload.tenantId || "demo-tenant-propflow";
  
  // Create a log entry tracking lead ingestion
  const logRef = collection(db, "automation_logs");
  const initialLog = await addDoc(logRef, {
    tenantId,
    leadId: payload.id || "pending",
    eventType: "Lead Ingested",
    executionTimestamp: new Date().toISOString(),
    status: "Success",
    details: `Ingested omnichannel payload from source: ${payload.leadSource || "Webhook Tester"}`
  });

  const leadId = payload.id || `lead_${Date.now()}`;
  
  try {
    // 1. Fetch Tenant configuration (e.g. routing rules)
    const tenantDocRef = doc(db, "tenants", tenantId);
    const tenantDoc = await getDoc(tenantDocRef);
    const tenantData = tenantDoc.exists() ? tenantDoc.data() : null;
    const routingRules = tenantData?.routingRules || [];
    const companyName = tenantData?.companyName || "PropFlow Partner";

    // 2. Fetch Users (Executives) of this tenant to assign the lead
    const usersSnap = await getDocs(collection(db, "users"));
    const executives = usersSnap.docs
      .map(d => ({ id: d.id, ...d.data() as any }))
      .filter(u => u.tenantId === tenantId && u.role === "Executive");

    // Default assignee fallback: pick the first executive or 'system-router'
    let assignedExecutiveId = executives.length > 0 ? executives[0].id : "unassigned";
    let routingReason = "Assigned via standard location rule fallback.";

    // Run AI routing if we have Gemini and multiple executives
    const ai = getGeminiClient();
    if (ai && executives.length > 0) {
      try {
        const prompt = `
          You are the PropFlow B2B SaaS Intelligent Lead Router.
          Assign the following incoming lead to the best matching sales executive.
          
          Incoming Lead Payload:
          ${JSON.stringify(payload, null, 2)}

          Available Executive Sales Team:
          ${JSON.stringify(executives, null, 2)}

          Matching Rules:
          - Match by the executive's preferred city or target project if available in the rules.
          - Distribute evenly or select the person with matching budget experience.
          
          Respond ONLY with a JSON object matching this schema:
          {
            "assignedExecutiveId": "string",
            "routingReason": "string"
          }
        `;

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                assignedExecutiveId: { type: Type.STRING },
                routingReason: { type: Type.STRING }
              },
              required: ["assignedExecutiveId", "routingReason"]
            }
          }
        });

        const result = JSON.parse(response.text?.trim() || "{}");
        if (result.assignedExecutiveId && executives.some(e => e.id === result.assignedExecutiveId)) {
          assignedExecutiveId = result.assignedExecutiveId;
          routingReason = result.routingReason;
        }
      } catch (aiErr: any) {
        console.warn("AI Routing failed, falling back to static logic:", aiErr.message);
      }
    }

    // 3. Generate Automated Welcoming Message using AI or default template
    let welcomeMessage = `Hello ${payload.customerName || "Valued Client"}, thank you for inquiring about ${payload.project || "our upcoming project"}. A PropFlow executive will contact you shortly.`;
    const aiWelcome = getGeminiClient();
    if (aiWelcome) {
      try {
        const promptWelcome = `
          Write a concise, welcoming, professional WhatsApp or SMS intro message (max 150 characters) 
          for a real estate buyer who just submitted an inquiry.
          Customer Name: ${payload.customerName || "Customer"}
          Property of Interest: ${payload.project || "Premium Property"}
          Company Name: ${companyName}
          Make it warm, premium, and specify that an agent will contact them soon. Do not use placeholders or markdown.
        `;
        const responseWelcome = await aiWelcome.models.generateContent({
          model: "gemini-3.5-flash",
          contents: promptWelcome
        });
        if (responseWelcome.text) {
          welcomeMessage = responseWelcome.text.trim();
        }
      } catch (welcErr) {
        // fallback to standard
      }
    }

    // 4. Save the lead in Firestore
    const leadRef = doc(db, "leads", leadId);
    const newLead = {
      id: leadId,
      tenantId,
      leadDate: payload.leadDate || new Date().toISOString(),
      customerName: payload.customerName || "Unknown Name",
      mobileNumber: payload.mobileNumber || "N/A",
      city: payload.city || "Mumbai",
      budget: Number(payload.budget) || 12000000,
      project: payload.project || "PropFlow Residency",
      unitType: payload.unitType || "2 BHK",
      leadSource: payload.leadSource || "Website",
      assignedExecutiveId,
      leadStatus: "New",
      nextFollowUpDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // set to tomorrow
      automationStatus: "On Track",
      notes: `Lead received via API gateway. ${routingReason}`
    };
    await setDoc(leadRef, newLead);

    // 5. Save Automation Logs
    await addDoc(collection(db, "automation_logs"), {
      tenantId,
      leadId,
      eventType: "AI Routing",
      executionTimestamp: new Date().toISOString(),
      status: "Success",
      details: `Lead allocated to sales executive ID: ${assignedExecutiveId}. Reason: ${routingReason}`
    });

    await addDoc(collection(db, "automation_logs"), {
      tenantId,
      leadId,
      eventType: "Welcome Text Dispatched",
      executionTimestamp: new Date().toISOString(),
      status: "Success",
      details: `Dispatched automated welcome message: "${welcomeMessage}"`
    });

    res.json({
      success: true,
      leadId,
      assignedExecutiveId,
      routingReason,
      welcomeMessage
    });
  } catch (error: any) {
    console.error("Webhook processing error:", error);
    await addDoc(collection(db, "automation_logs"), {
      tenantId,
      leadId,
      eventType: "Routing Exception",
      executionTimestamp: new Date().toISOString(),
      status: "Failure",
      details: `Error processing omnichannel lead webhook: ${error.message}`
    });
    res.status(500).json({ success: false, error: error.message });
  }
});

// Start dev server with Vite configuration or serve static folder
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[PropFlow CRM Engine] Backend Running on http://localhost:${PORT}`);
  });
}

startServer();
