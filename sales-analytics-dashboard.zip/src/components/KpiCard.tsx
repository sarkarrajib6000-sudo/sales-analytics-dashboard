import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';
import { cn } from "../lib/utils";

interface KpiCardProps {
  title: string;
  value: string;
  change: string;
  icon?: React.ReactNode;
  key?: React.Key;
}

export function KpiCard({ title, value, change, icon }: KpiCardProps) {
  const isPositive = change.startsWith('+');
  
  return (
    <div className={cn(
      "bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm transition-all duration-300 hover:shadow-md",
      "border-l-4",
      isPositive ? "border-l-emerald-500" : "border-l-rose-500"
    )}>
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">{title}</p>
          <h3 className="text-2xl font-bold text-slate-900 dark:text-white mt-2">{value}</h3>
        </div>
        {icon && (
          <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-lg">
            {icon}
          </div>
        )}
      </div>
      <p className={cn("text-xs font-semibold mt-3 flex items-center gap-1", isPositive ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400")}>
        {isPositive ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
        {change} <span className="text-slate-400 dark:text-slate-500 font-normal ml-0.5">vs last month</span>
      </p>
    </div>
  );
}
