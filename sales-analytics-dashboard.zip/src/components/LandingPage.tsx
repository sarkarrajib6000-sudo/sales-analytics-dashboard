import React from 'react';
import { ArrowRight, BarChart3, TrendingUp, Users } from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

export function LandingPage({ onGetStarted }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 flex flex-col items-center justify-center p-6 text-white">
      <div className="max-w-4xl text-center">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight">
          Visualize Your Success.
        </h1>
        <p className="text-xl md:text-2xl text-indigo-100 mb-10 max-w-2xl mx-auto">
          Turn your raw data into actionable insights with our intuitive, colorful, and powerful analytics dashboard.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
            <BarChart3 className="mx-auto mb-4 text-pink-300" size={32} />
            <h3 className="font-semibold text-lg mb-2">Real-time Analytics</h3>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
            <TrendingUp className="mx-auto mb-4 text-purple-300" size={32} />
            <h3 className="font-semibold text-lg mb-2">Trend Analysis</h3>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
            <Users className="mx-auto mb-4 text-indigo-300" size={32} />
            <h3 className="font-semibold text-lg mb-2">Customer Insights</h3>
          </div>
        </div>

        <button 
          onClick={onGetStarted}
          className="bg-white text-indigo-600 px-8 py-4 rounded-full font-bold text-lg flex items-center gap-2 hover:bg-indigo-50 transition-all shadow-lg mx-auto"
        >
          Go to Dashboard <ArrowRight size={20} />
        </button>
      </div>
    </div>
  );
}
