import { LayoutDashboard, BarChart3, Users, Settings, ChevronLeft, ChevronRight, Package, ShoppingCart } from 'lucide-react';
import { useState } from 'react';
import { cn } from '../lib/utils';

interface SidebarProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  const menuItems = [
    { name: 'Dashboard', id: 'dashboard', icon: LayoutDashboard },
    { name: 'Revenue', id: 'revenue', icon: BarChart3 },
    { name: 'Profit', id: 'profit', icon: BarChart3 },
    { name: 'Products', id: 'product', icon: Package },
    { name: 'Orders', id: 'orders', icon: ShoppingCart },
    { name: 'Customers', id: 'customers', icon: Users },
    { name: 'Settings', id: 'settings', icon: Settings },
  ];

  return (
    <div className={cn(
      "h-screen bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transition-all duration-300 flex flex-col",
      collapsed ? "w-16" : "w-64"
    )}>
      <div className="p-4 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
        {!collapsed && <span className="font-bold text-lg dark:text-white">SalesAnalytics</span>}
        <button onClick={() => setCollapsed(!collapsed)} className="p-1 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500">
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>
      
      <nav className="flex-1 mt-4 space-y-1">
        {menuItems.map((item) => (
          <button 
            key={item.name} 
            onClick={() => onTabChange && onTabChange(item.id)}
            className={cn(
              "flex items-center w-full px-4 py-3 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
              activeTab === item.id && "bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 border-r-2 border-indigo-600"
            )}
          >
            <item.icon size={20} />
            {!collapsed && <span className="ml-3 font-medium">{item.name}</span>}
          </button>
        ))}
      </nav>
    </div>
  );
}
