import { Moon, Sun, Search, Bell, Download } from 'lucide-react';
import { useState, useEffect } from 'react';
import { DateRangePicker } from './DateRangePicker';

interface HeaderProps {
  onExport: () => void;
  filterText: string;
  onFilterChange: (text: string) => void;
}

export function Header({ onExport, filterText, onFilterChange }: HeaderProps) {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  return (
    <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-8">
      <div className="relative w-96">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
        <input 
          type="text" 
          value={filterText}
          onChange={(e) => onFilterChange(e.target.value)}
          placeholder="Search by customer..." 
          className="w-full pl-10 pr-4 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 border-transparent focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all outline-none dark:text-white"
        />
      </div>
      
      <div className="flex items-center gap-4">
        <DateRangePicker />
        <button 
          onClick={onExport}
          className="flex items-center gap-2 p-2 rounded-lg bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 font-medium text-sm"
        >
          <Download size={18} />
          Export
        </button>
        <button 
          onClick={() => setIsDark(!isDark)}
          className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
        >
          {isDark ? <Sun size={20} /> : <Moon size={20} />}
        </button>
        <button className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
          <Bell size={20} />
        </button>
        <div className="flex items-center gap-2 ml-2">
          <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white font-medium">
            RJ
          </div>
          <span className="text-sm font-medium dark:text-white">Rajib</span>
        </div>
      </div>
    </header>
  );
}
