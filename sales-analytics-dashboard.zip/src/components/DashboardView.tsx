import React, { useState, useEffect } from 'react';
import { KpiCard } from './KpiCard';
import { PivotTable } from './PivotTable';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { dbService } from '../lib/dbService';
import { TrendingUp, BarChart3, Wallet, ShoppingBag } from 'lucide-react';

interface DashboardViewProps {
  orders: any[];
}

export function DashboardView({ orders }: DashboardViewProps) {
  const [kpis, setKpis] = useState(dbService.getKPIs());
  const [sales, setSales] = useState(dbService.getSales());

  useEffect(() => {
    const handleUpdate = () => {
      setKpis(dbService.getKPIs());
      setSales(dbService.getSales());
    };
    window.addEventListener('sales_db_update', handleUpdate);
    return () => window.removeEventListener('sales_db_update', handleUpdate);
  }, []);

  // Map icons to the KPI cards dynamically
  const getIcon = (title: string) => {
    switch (title) {
      case 'Total Revenue':
        return <BarChart3 className="text-indigo-600 dark:text-indigo-400" size={20} />;
      case 'Total Profit':
        return <TrendingUp className="text-emerald-600 dark:text-emerald-400" size={20} />;
      case 'Profit Margin':
        return <Wallet className="text-purple-600 dark:text-purple-400" size={20} />;
      default:
        return <ShoppingBag className="text-blue-600 dark:text-blue-400" size={20} />;
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Executive Dashboard</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">High-level view of your business performance, trends, and revenue metrics.</p>
      </div>

      {/* KPIs Section */}
      <div>
        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4 flex items-center gap-2">
          <span className="w-1.5 h-6 bg-indigo-600 rounded-full inline-block"></span>
          Key Performance Indicators (KPIs)
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {kpis.map((kpi, i) => (
            <KpiCard key={idx_safe_i(i, kpi.title)} title={kpi.title} value={kpi.value} change={kpi.change} icon={getIcon(kpi.title)} />
          ))}
        </div>
      </div>

      {/* Revenue Trend Section */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4 flex items-center gap-2">
          <span className="w-1.5 h-6 bg-indigo-600 rounded-full inline-block"></span>
          Revenue Trend (Monthly)
        </h3>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sales} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(val) => `$${val / 1000}k`} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                formatter={(val) => [`$${Number(val).toLocaleString()}`, 'Revenue']}
              />
              <Area type="monotone" dataKey="revenue" stroke="#4f46e5" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRevenue)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Revenue Section */}
      <div>
        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 flex items-center gap-2">
          <span className="w-1.5 h-6 bg-indigo-600 rounded-full inline-block"></span>
          Revenue Distribution (Customer Pivot)
        </h3>
        <PivotTable orders={orders} />
      </div>
    </div>
  );
}

function idx_safe_i(i: number, title: string) {
  return `${title}-${i}`;
}

