import React, { useState, useCallback, useRef, useEffect } from 'react';
import Papa from 'papaparse';
import { Upload, Download, Info, FileText, CheckCircle, MoreVertical } from 'lucide-react';

interface CsvUploaderProps {
  onDataLoaded: (data: any[]) => void;
}

export function CsvUploader({ onDataLoaded }: CsvUploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [showFormatGuide, setShowFormatGuide] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [fileName, setFileName] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);

  const menuRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const parseCsvFile = (file: File) => {
    setFileName(file.name);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        onDataLoaded(results.data);
        setUploadSuccess(true);
        setTimeout(() => setUploadSuccess(false), 4000);
      },
      error: (error) => {
        console.error('Error parsing CSV:', error);
      }
    });
  };

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) parseCsvFile(file);
  }, [onDataLoaded]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type === 'text/csv') {
      parseCsvFile(file);
    }
  }, [onDataLoaded]);

  // Generate and download a sample CSV file
  const downloadSampleCSV = () => {
    const headers = [
      'id', 'customer', 'segment', 'date', 'status', 'revenue', 
      'profit', 'priority', 'productName', 'category', 'region', 
      'country', 'channel'
    ];
    
    const sampleRows = [
      ['ORD-2001', 'Acme Corporation', 'Enterprise', '12 Jan 2026', 'Delivered', '1200', '432', 'High', 'Pro Laptop 15"', 'Electronics', 'North America', 'United States', 'Online Direct'],
      ['ORD-2002', 'Stark Industries', 'Enterprise', '15 Feb 2026', 'Shipped', '150', '45', 'Critical', 'Smart Fitness Watch', 'Electronics', 'Europe', 'United Kingdom', 'Wholesale B2B'],
      ['ORD-2003', 'Initech LLC', 'SMB', '22 Mar 2026', 'Processing', '250', '70', 'Medium', 'Ergonomic Desk Chair', 'Home & Kitchen', 'North America', 'Canada', 'Retail Store'],
      ['ORD-2004', 'Dunder Mifflin', 'SMB', '05 Apr 2026', 'Cancelled', '50', '17', 'Low', 'Duffle Sports Bag', 'Sports & Outdoors', 'North America', 'United States', 'Social Commerce']
    ];

    const csvContent = [
      headers.join(','),
      ...sampleRows.map(row => row.map(val => `"${val.replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'sales_data_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const requiredColumns = [
    { name: 'customer', desc: 'Customer name (e.g., Acme Corporation)', required: true },
    { name: 'revenue', desc: 'Revenue amount as a number (e.g., 1200)', required: true },
    { name: 'date', desc: 'Format: DD MMM YYYY (e.g., 12 Jan 2026)', required: false },
    { name: 'productName', desc: 'Product purchased (e.g., Pro Laptop 15")', required: false },
    { name: 'profit', desc: 'Profit amount (defaults to 35% of revenue)', required: false },
    { name: 'status', desc: 'Delivered | Shipped | Processing | Cancelled', required: false },
    { name: 'priority', desc: 'Critical | High | Medium | Low', required: false },
    { name: 'category', desc: 'Electronics | Home & Kitchen | Sports & Outdoors', required: false },
    { name: 'segment', desc: 'Enterprise | Mid-Market | SMB', required: false },
    { name: 'region', desc: 'North America | Europe | Asia', required: false },
    { name: 'country', desc: 'United States | Canada | United Kingdom | Germany | Japan', required: false },
    { name: 'channel', desc: 'Online Direct | Retail Store | Wholesale B2B | Social Commerce', required: false },
  ];

  return (
    <div className="space-y-2.5" id="csv-uploader-section">
      {/* Compact Upload Bar */}
      <div className="flex items-center justify-between gap-3 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-2 px-3 shadow-sm">
        {/* Drag & Drop Zone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`flex-1 flex items-center gap-3 cursor-pointer select-none rounded-lg p-1.5 transition-all duration-200 ${
            isDragging
              ? 'bg-indigo-50/50 dark:bg-indigo-950/20 outline-2 outline-dashed outline-indigo-500'
              : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
          }`}
        >
          {/* Hidden file input */}
          <input
            type="file"
            accept=".csv"
            ref={fileInputRef}
            onChange={handleFileUpload}
            className="hidden"
          />
          
          <div className={`p-1.5 rounded-lg transition-colors ${
            uploadSuccess 
              ? 'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400' 
              : 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400'
          }`}>
            {uploadSuccess ? <CheckCircle size={15} /> : <Upload size={15} />}
          </div>
          
          <div className="min-w-0 flex-1">
            <h4 className="text-[11px] font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 leading-tight">
              {uploadSuccess ? 'Data Loaded' : 'Import Custom Sales CSV'}
              {uploadSuccess && (
                <span className="text-[9px] font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30 px-1 py-0.2 rounded">
                  Success
                </span>
              )}
            </h4>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 truncate max-w-[200px] sm:max-w-xs md:max-w-md leading-tight mt-0.5">
              {uploadSuccess 
                ? `File: ${fileName}` 
                : 'Drag file here or click to browse'}
            </p>
          </div>
        </div>

        {/* 3-Dot Dropdown Trigger */}
        <div className="relative flex items-center" ref={menuRef}>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
            title="Options"
          >
            <MoreVertical size={15} />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg shadow-lg z-50 p-1 w-44 text-slate-700 dark:text-slate-200 animate-fade-in">
              <button
                onClick={() => {
                  fileInputRef.current?.click();
                  setMenuOpen(false);
                }}
                className="w-full flex items-center gap-2 px-2 py-1.5 text-[11px] font-semibold rounded-md hover:bg-slate-50 dark:hover:bg-slate-800 text-left transition-colors"
              >
                <Upload size={13} className="text-indigo-500" />
                Browse Files
              </button>
              
              <button
                onClick={() => {
                  downloadSampleCSV();
                  setMenuOpen(false);
                }}
                className="w-full flex items-center gap-2 px-2 py-1.5 text-[11px] font-semibold rounded-md hover:bg-slate-50 dark:hover:bg-slate-800 text-left transition-colors"
              >
                <Download size={13} className="text-emerald-500" />
                Get Template CSV
              </button>
              
              <div className="border-t border-slate-100 dark:border-slate-800/80 my-1"></div>
              
              <button
                onClick={() => {
                  setShowFormatGuide(!showFormatGuide);
                  setMenuOpen(false);
                }}
                className="w-full flex items-center gap-2 px-2 py-1.5 text-[11px] font-semibold rounded-md hover:bg-slate-50 dark:hover:bg-slate-800 text-left transition-colors"
              >
                <Info size={13} className="text-amber-500" />
                {showFormatGuide ? 'Hide Format Guide' : 'Format Guide'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Accordion Format & Column Guide */}
      {showFormatGuide && (
        <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl p-4 space-y-3 animate-fade-in">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
            <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <FileText size={11} className="text-indigo-500" />
              CSV Format Specifications
            </h4>
            <span className="text-[9px] text-slate-400 font-medium">Headers are case-sensitive</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
            {requiredColumns.map((col) => (
              <div 
                key={col.name} 
                className="flex flex-col p-2 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/60 rounded-lg hover:shadow-sm transition-all"
              >
                <div className="flex items-center justify-between gap-1.5">
                  <code className="text-[9px] font-mono font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/20 px-1.5 py-0.2 rounded">
                    {col.name}
                  </code>
                  {col.required ? (
                    <span className="text-[8px] font-bold uppercase tracking-wider px-1 py-0.2 rounded bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400">
                      Required
                    </span>
                  ) : (
                    <span className="text-[8px] font-bold uppercase tracking-wider px-1 py-0.2 rounded bg-slate-100 text-slate-500 dark:bg-slate-800/80 dark:text-slate-400">
                      Optional
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                  {col.desc}
                </p>
              </div>
            ))}
          </div>

          <div className="bg-indigo-50/30 dark:bg-indigo-950/10 border border-indigo-100/30 dark:border-indigo-900/25 p-2.5 rounded-lg text-[10px] text-slate-500 dark:text-slate-400 flex items-start gap-2">
            <Info size={13} className="text-indigo-500 mt-0.5 flex-shrink-0" />
            <div className="space-y-0.5">
              <p className="font-bold text-slate-600 dark:text-slate-300">Format & Analysis Tips</p>
              <p>
                Ensure <strong>revenue</strong> is a valid number, and <strong>date</strong> follows <code>DD MMM YYYY</code> (e.g. <code>24 May 2025</code>). Optional values default automatically if left out.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
