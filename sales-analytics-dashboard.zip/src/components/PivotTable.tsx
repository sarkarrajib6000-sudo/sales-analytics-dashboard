import { useState } from 'react';
import { LayoutGrid, List } from 'lucide-react';
import { cn } from '../lib/utils';

export function PivotTable({ orders }: { orders: any[] }) {
  const [view, setView] = useState<'table' | 'card'>('table');
  // Simple pivot table logic: Aggregate revenue by customer and status
  const pivotData = orders.reduce((acc, order) => {
    const key = `${order.customer}-${order.status}`;
    if (!acc[key]) {
      acc[key] = { customer: order.customer, status: order.status, totalRevenue: 0 };
    }
    acc[key].totalRevenue += order.revenue;
    return acc;
  }, {});

  const rows = Object.values(pivotData) as any[];

  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm mt-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Sales Pivot Table (Customer vs Status)</h3>
        <div className="flex bg-slate-100 dark:bg-slate-800 rounded-lg p-1">
          <button onClick={() => setView('table')} className={cn("p-1.5 rounded-md", view === 'table' ? "bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-indigo-400" : "text-slate-500")}>
            <List size={16} />
          </button>
          <button onClick={() => setView('card')} className={cn("p-1.5 rounded-md", view === 'card' ? "bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-indigo-400" : "text-slate-500")}>
            <LayoutGrid size={16} />
          </button>
        </div>
      </div>
      
      {view === 'table' ? (
        <table className="w-full text-left">
          <thead>
            <tr className="text-slate-700 dark:text-slate-300 border-b-2 border-indigo-200 dark:border-indigo-900 bg-indigo-50 dark:bg-indigo-950/30">
              <th className="pb-3 pl-4">Customer</th>
              <th className="pb-3">Status</th>
              <th className="pb-3 text-right pr-4">Total Revenue</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {rows.map((row, i) => (
              <tr key={i} className="text-slate-900 dark:text-slate-200 even:bg-indigo-50/50 dark:even:bg-slate-800/50 hover:bg-indigo-100 dark:hover:bg-slate-700 transition-colors">
                <td className="py-4 pl-4 font-medium text-indigo-700 dark:text-indigo-300">{row.customer}</td>
                <td className="py-4">{row.status}</td>
                <td className="py-4 text-right pr-4 font-semibold text-emerald-600 dark:text-emerald-400">${row.totalRevenue.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {rows.map((row, i) => (
            <div key={i} className="p-4 border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800">
              <div className="flex justify-between">
                <p className="font-semibold text-slate-900 dark:text-white">{row.customer}</p>
                <span className="text-xs px-2 py-1 rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400">{row.status}</span>
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">Revenue: ${row.totalRevenue.toLocaleString()}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
