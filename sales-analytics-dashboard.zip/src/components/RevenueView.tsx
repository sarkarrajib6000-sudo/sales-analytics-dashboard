import React, { useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend, AreaChart, Area
} from 'recharts';
import { dbService } from '../lib/dbService';
import { Coins, Filter, DollarSign, Calendar, Tag, Package, MapPin, Globe, Share2, TrendingUp } from 'lucide-react';

export function RevenueView({ salesData: monthlyDataProps }: { salesData?: any[] }) {
  const [currentFilter, setCurrentFilter] = useState(dbService.getDateRange());
  const [revenueTimeGrouping, setRevenueTimeGrouping] = useState<'year' | 'month'>('year');

  // Relational Database reactive state hook
  const [sales, setSales] = useState(dbService.getSales());
  const [yearly, setYearly] = useState(dbService.getYearly());
  const [category, setCategory] = useState(dbService.getCategory());
  const [products, setProducts] = useState(dbService.getProducts());
  const [countries, setCountries] = useState(dbService.getCountries());
  const [regions, setRegions] = useState(dbService.getRegions());
  const [channels, setChannels] = useState(dbService.getChannels());

  const refreshDBState = () => {
    setCurrentFilter(dbService.getDateRange());
    setSales(dbService.getSales());
    setYearly(dbService.getYearly());
    setCategory(dbService.getCategory());
    setProducts(dbService.getProducts());
    setCountries(dbService.getCountries());
    setRegions(dbService.getRegions());
    setChannels(dbService.getChannels());
  };

  useEffect(() => {
    refreshDBState();
    window.addEventListener('sales_db_update', refreshDBState);
    return () => window.removeEventListener('sales_db_update', refreshDBState);
  }, []);

  // Compute active filters for the slicers
  const activeYear = currentFilter.type === 'all' ? 'All' : currentFilter.year || 'All';
  const activeMonth = currentFilter.type === 'month' ? currentFilter.month || 'All' : 'All';

  const handleSlicerChange = (year: string, month: string) => {
    if (year === 'All' && month === 'All') {
      dbService.setDateRange({ type: 'all' });
    } else if (month === 'All') {
      dbService.setDateRange({ type: 'year', year });
    } else {
      const targetYear = year === 'All' ? '2025' : year;
      dbService.setDateRange({ type: 'month', year: targetYear, month });
    }
  };
  
  // Custom colors for charts
  const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4'];

  return (
    <div className="flex flex-col lg:flex-row gap-8 animate-fade-in text-slate-800 dark:text-slate-100">
      {/* Main Analysis Column */}
      <div className="flex-1 space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <Coins className="text-indigo-600 dark:text-indigo-400" size={28} />
              Revenue Analysis
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">Comprehensive view of business cashflows across time, channels, categories, products, and geographies.</p>
          </div>
          <div className="flex items-center gap-2 bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm">
            <Filter size={16} className="text-slate-400" />
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Year Filter:</span>
            <select 
              value={activeYear} 
              onChange={(e) => handleSlicerChange(e.target.value, activeMonth)}
              className="text-xs bg-transparent font-medium border-none focus:outline-none dark:text-slate-200 cursor-pointer text-slate-700 dark:text-slate-300"
            >
              <option value="All" className="dark:bg-slate-900 text-slate-800 dark:text-slate-100">All Years</option>
              <option value="2026" className="dark:bg-slate-900 text-slate-800 dark:text-slate-100">2026</option>
              <option value="2025" className="dark:bg-slate-900 text-slate-800 dark:text-slate-100">2025</option>
              <option value="2024" className="dark:bg-slate-900 text-slate-800 dark:text-slate-100">2024</option>
            </select>
          </div>
        </div>

        {/* 0. Revenue & Profit Overlapping Monthly Trend */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <TrendingUp className="text-indigo-500" size={18} />
                Monthly Revenue & Profit Overlap Trend
              </h3>
              <p className="text-xs text-slate-400">Overlapping area visualization tracking revenue flow against net earnings</p>
            </div>
            <div className="flex items-center gap-4 text-xs font-semibold">
              <div className="flex items-center gap-1.5">
                <div className="w-3.5 h-3.5 rounded bg-indigo-500/20 border-2 border-indigo-600" />
                <span className="text-slate-600 dark:text-slate-300">Revenue</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3.5 h-3.5 rounded bg-emerald-500/20 border-2 border-emerald-500" />
                <span className="text-slate-600 dark:text-slate-300">Profit</span>
              </div>
            </div>
          </div>
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sales} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(val) => `$${val / 1000}k`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                  formatter={(val, name) => [`$${Number(val).toLocaleString()}`, name === 'revenue' ? 'Revenue' : 'Profit']}
                />
                <Area type="monotone" dataKey="revenue" stroke="#4f46e5" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRevenue)" name="revenue" />
                <Area type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorProfit)" name="profit" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* 1. Revenue by Year */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between gap-4 mb-4">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar className="text-indigo-500" size={18} />
                {revenueTimeGrouping === 'year' ? 'Revenue by Year' : 'Revenue by Month'}
              </h3>
              <p className="text-xs text-slate-400">
                {revenueTimeGrouping === 'year' ? 'Comparison of year-over-year revenue progress' : 'Monthly trend breakdown of sales performance'}
              </p>
            </div>
            
            {/* Toggle Switch Button Group */}
            <div className="flex p-0.5 bg-slate-100 dark:bg-slate-800/80 rounded-lg border border-slate-200/50 dark:border-slate-700/50">
              <button
                onClick={() => setRevenueTimeGrouping('year')}
                className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-all ${
                  revenueTimeGrouping === 'year'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm'
                    : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                Year
              </button>
              <button
                onClick={() => setRevenueTimeGrouping('month')}
                className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-all ${
                  revenueTimeGrouping === 'month'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm'
                    : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                Month
              </button>
            </div>
          </div>
          <div className="h-[260px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              {revenueTimeGrouping === 'year' ? (
                <BarChart data={yearly} margin={{ left: -15, right: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                  <XAxis dataKey="year" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(val) => `$${val / 1000}k`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                    formatter={(val) => [`$${Number(val).toLocaleString()}`, 'Revenue']}
                  />
                  <Bar dataKey="revenue" fill="#4f46e5" radius={[6, 6, 0, 0]} maxBarSize={60} />
                </BarChart>
              ) : (
                <BarChart data={sales} margin={{ left: -15, right: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(val) => `$${val / 1000}k`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                    formatter={(val) => [`$${Number(val).toLocaleString()}`, 'Revenue']}
                  />
                  <Bar dataKey="revenue" fill="#6366f1" radius={[4, 4, 0, 0]} maxBarSize={30} />
                </BarChart>
              )}
            </ResponsiveContainer>
          </div>
        </div>

        {/* 2. Revenue by Category */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Tag className="text-emerald-500" size={18} />
              Revenue by Category
            </h3>
            <p className="text-xs text-slate-400">Performance split across top product categories</p>
          </div>
          <div className="h-[260px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={category} layout="vertical" margin={{ left: 15, right: 10 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                <XAxis type="number" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(val) => `$${val / 1000}k`} />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 11 }} width={80} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                  formatter={(val) => [`$${Number(val).toLocaleString()}`, 'Revenue']}
                />
                <Bar dataKey="revenue" fill="#10b981" radius={[0, 6, 6, 0]} maxBarSize={30} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 3. Revenue by Product */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Package className="text-purple-500" size={18} />
              Revenue by Product
            </h3>
            <p className="text-xs text-slate-400">Total cashflow contributions by individual items</p>
          </div>
          <div className="h-[260px] overflow-y-auto pr-1 space-y-3 custom-scrollbar">
            {products.slice(0, 5).map((product, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold text-sm">
                    #{i + 1}
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-slate-800 dark:text-slate-200">{product.name}</h4>
                    <p className="text-xs text-slate-400">{product.units} Units Sold</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-bold text-slate-900 dark:text-slate-100">${product.revenue.toLocaleString()}</span>
                  <div className="w-24 bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-1.5 overflow-hidden">
                    <div 
                      className="bg-indigo-500 h-full rounded-full" 
                      style={{ width: `${products[0] && products[0].revenue ? (product.revenue / products[0].revenue) * 100 : 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Revenue by Country */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Globe className="text-sky-500" size={18} />
              Revenue by Country
            </h3>
            <p className="text-xs text-slate-400">Global revenue share and contribution</p>
          </div>
          <div className="h-[260px] w-full flex flex-col justify-center space-y-4">
            {countries.map((country, i) => (
              <div key={i} className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <div className="flex items-center gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-mono text-slate-500 dark:text-slate-400">{country.code}</span>
                    <span>{country.country}</span>
                  </div>
                  <span>${country.revenue.toLocaleString()}</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full bg-sky-500" 
                    style={{ width: `${countries[0] && countries[0].revenue ? (country.revenue / countries[0].revenue) * 100 : 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 5. Revenue by Region */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <MapPin className="text-rose-500" size={18} />
              Revenue by Region
            </h3>
            <p className="text-xs text-slate-400">Consolidated revenue by world zones</p>
          </div>
          <div className="h-[260px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={regions} margin={{ left: -15, right: 10 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(val) => `$${val / 1000}k`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                  formatter={(val) => [`$${Number(val).toLocaleString()}`, 'Revenue']}
                />
                <Bar dataKey="revenue" fill="#f43f5e" radius={[6, 6, 0, 0]} maxBarSize={45} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 6. Revenue by Channel */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Share2 className="text-amber-500" size={18} />
              Revenue by Channel
            </h3>
            <p className="text-xs text-slate-400">Inbound sales channel proportion</p>
          </div>
          <div className="h-[260px] w-full flex flex-col md:flex-row items-center justify-around">
            <div className="w-[180px] h-[180px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={channels}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={75}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {channels.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(val) => `$${Number(val).toLocaleString()}`} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2 mt-4 md:mt-0">
              {channels.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 w-28">{item.name}</span>
                  <span className="text-xs font-bold text-slate-900 dark:text-white">${item.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

    </div>

      {/* Slicer Sidebar on the Right */}
      <div className="w-full lg:w-[240px] shrink-0">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-5 sticky top-6">
          <div className="flex items-center gap-2 pb-2.5 border-b border-slate-150 dark:border-slate-800">
            <Filter size={15} className="text-indigo-600 dark:text-indigo-400" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Interactive Slicers</h4>
          </div>

          {/* Year Slicer */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Year Filter</span>
            <div className="flex flex-wrap gap-1.5">
              {['All', '2026', '2025', '2024'].map(yr => {
                const isSelected = activeYear === yr;
                return (
                  <button
                    key={yr}
                    onClick={() => handleSlicerChange(yr, activeMonth)}
                    className={`text-xs font-semibold px-2.5 py-1.5 rounded-lg border transition-all ${
                      isSelected
                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm font-bold'
                        : 'bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 border-slate-200/60 dark:border-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {yr}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Month Slicer */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Month Filter</span>
            <div className="grid grid-cols-3 gap-1.5">
              {['All', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map(m => {
                const isSelected = activeMonth === m;
                const isFuture2026 = activeYear === '2026' && m !== 'All' && ['Aug', 'Sep', 'Oct', 'Nov', 'Dec'].includes(m);
                return (
                  <button
                    key={m}
                    disabled={isFuture2026}
                    onClick={() => handleSlicerChange(activeYear, m)}
                    className={`text-[10px] font-semibold py-1.5 rounded-lg border text-center transition-all ${
                      isFuture2026
                        ? 'opacity-30 cursor-not-allowed border-transparent bg-transparent text-slate-300 dark:text-slate-700'
                        : isSelected
                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm font-bold'
                        : 'bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 border-slate-200/60 dark:border-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {m}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-150 dark:border-slate-800 flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Selected range:</span>
            <span className="font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded">
              {activeYear === 'All' && activeMonth === 'All' ? 'All Time' : activeMonth === 'All' ? activeYear : `${activeMonth} ${activeYear}`}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
